var classmodel_1_1dataclass_1_1_autore =
[
    [ "Autore", "classmodel_1_1dataclass_1_1_autore.html#af34ce603d1ace7300cd1a13c02966a1d", null ],
    [ "getCognome", "classmodel_1_1dataclass_1_1_autore.html#ad342b9075b8a53a179257aa4cadd4ac1", null ],
    [ "getData_nascita", "classmodel_1_1dataclass_1_1_autore.html#a78f74eb1b48e4f008782ab762fb3b486", null ],
    [ "getId", "classmodel_1_1dataclass_1_1_autore.html#a756ef09b4cabe3abde6a03388b97427a", null ],
    [ "getNome", "classmodel_1_1dataclass_1_1_autore.html#a45a4bcec38c6e50e85b489aacb5aef3f", null ],
    [ "getOpere_scritte", "classmodel_1_1dataclass_1_1_autore.html#aba7dd6cad92d02c491895ca483bd0c25", null ],
    [ "setCognome", "classmodel_1_1dataclass_1_1_autore.html#a5b4587abd5413ebbdd244278b1a1e82f", null ],
    [ "setData_nascita", "classmodel_1_1dataclass_1_1_autore.html#af240ba0fb29a12be5de157b75dc035c0", null ],
    [ "setId", "classmodel_1_1dataclass_1_1_autore.html#a0158f6364c019977596d5a147ba60ed7", null ],
    [ "setNome", "classmodel_1_1dataclass_1_1_autore.html#a7f23583e41693773cdc5a5263b114d57", null ],
    [ "setOpere_scritte", "classmodel_1_1dataclass_1_1_autore.html#a2e2f20008e26f378b270aa39952ddf4b", null ],
    [ "toString", "classmodel_1_1dataclass_1_1_autore.html#a03281a27ddbaa94b48eb9affbcc48b5e", null ]
];