var classcontroller_1_1_blacklist_controller_test =
[
    [ "setUpDB", "classcontroller_1_1_blacklist_controller_test.html#a494080b0588cb572345d9c6a1b5bc8c8", null ],
    [ "start", "classcontroller_1_1_blacklist_controller_test.html#a195d243dc83d63a04d321046e2acc97b", null ],
    [ "tearDown", "classcontroller_1_1_blacklist_controller_test.html#a9664f0cf9c321a41badf9b0dcdebe36a", null ],
    [ "testInizializzazioneLista", "classcontroller_1_1_blacklist_controller_test.html#ad94ba1ab6246f8d64451a6583b1bb70b", null ],
    [ "testRicercaUtente", "classcontroller_1_1_blacklist_controller_test.html#aa414f6c1c5063497dbb37a479dc1764e", null ],
    [ "testSbloccaSingolo", "classcontroller_1_1_blacklist_controller_test.html#a0a7d9c00b520b6daceefb51fb8bc2ab1", null ],
    [ "testSbloccaTutti", "classcontroller_1_1_blacklist_controller_test.html#aa7e57af6609d80ac805d2daa85ce4c60", null ]
];