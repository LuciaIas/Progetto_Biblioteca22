var searchData=
[
  ['transizionescena_0',['TransizioneScena',['../classmodel_1_1_transizione_scena.html',1,'model']]],
  ['transizionescenatest_1',['TransizioneScenaTest',['../classmodel_1_1_transizione_scena_test.html',1,'model']]]
];
