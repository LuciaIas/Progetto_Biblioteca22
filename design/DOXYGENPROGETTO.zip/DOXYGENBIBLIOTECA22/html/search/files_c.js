var searchData=
[
  ['stato_2ejava_0',['Stato.java',['../_stato_8java.html',1,'']]]
];
