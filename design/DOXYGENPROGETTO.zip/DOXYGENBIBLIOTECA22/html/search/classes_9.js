var searchData=
[
  ['operazionigiornaliere_0',['OperazioniGiornaliere',['../classmodel_1_1servizi_1_1_operazioni_giornaliere.html',1,'model::servizi']]],
  ['operazionigiornalieretest_1',['OperazioniGiornaliereTest',['../classmodel_1_1servizi_1_1_operazioni_giornaliere_test.html',1,'model::servizi']]]
];
