var searchData=
[
  ['notificacontroller_0',['NotificaController',['../classcontroller_1_1_notifica_controller.html',1,'controller']]],
  ['notificacontrollertest_1',['NotificaControllerTest',['../classcontroller_1_1_notifica_controller_test.html',1,'controller']]]
];
