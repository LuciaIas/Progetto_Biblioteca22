var _mail_controller_test_8java =
[
    [ "controller.MailControllerTest", "classcontroller_1_1_mail_controller_test.html", "classcontroller_1_1_mail_controller_test" ]
];