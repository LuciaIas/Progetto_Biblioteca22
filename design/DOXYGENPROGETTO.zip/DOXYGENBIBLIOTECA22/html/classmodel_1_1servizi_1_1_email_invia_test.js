var classmodel_1_1servizi_1_1_email_invia_test =
[
    [ "setUp", "classmodel_1_1servizi_1_1_email_invia_test.html#aba6b40482bcffb08a70e2f0afeae2e84", null ],
    [ "tearDown", "classmodel_1_1servizi_1_1_email_invia_test.html#a7e0b1272ba4498bdee27316136d6fbfd", null ],
    [ "testInviaAvvisoLibroSingolo", "classmodel_1_1servizi_1_1_email_invia_test.html#a1e372b8fe1f65357e6c8f165d666cc42", null ],
    [ "testInviaAvvisoMultiplo", "classmodel_1_1servizi_1_1_email_invia_test.html#adca87cfefdbb35f1c8db137aff08deb4", null ]
];