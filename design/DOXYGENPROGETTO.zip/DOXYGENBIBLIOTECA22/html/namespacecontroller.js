var namespacecontroller =
[
    [ "catalogo", "namespacecontroller_1_1catalogo.html", "namespacecontroller_1_1catalogo" ],
    [ "modificapassword", "namespacecontroller_1_1modificapassword.html", "namespacecontroller_1_1modificapassword" ],
    [ "prestitorestituzione", "namespacecontroller_1_1prestitorestituzione.html", "namespacecontroller_1_1prestitorestituzione" ],
    [ "utenti", "namespacecontroller_1_1utenti.html", "namespacecontroller_1_1utenti" ],
    [ "AccessoController", "classcontroller_1_1_accesso_controller.html", "classcontroller_1_1_accesso_controller" ],
    [ "BlacklistController", "classcontroller_1_1_blacklist_controller.html", "classcontroller_1_1_blacklist_controller" ],
    [ "DashboardController", "classcontroller_1_1_dashboard_controller.html", "classcontroller_1_1_dashboard_controller" ],
    [ "MailController", "classcontroller_1_1_mail_controller.html", "classcontroller_1_1_mail_controller" ],
    [ "NotificaController", "classcontroller_1_1_notifica_controller.html", "classcontroller_1_1_notifica_controller" ],
    [ "AccessoControllerTest", "classcontroller_1_1_accesso_controller_test.html", "classcontroller_1_1_accesso_controller_test" ],
    [ "BlacklistControllerTest", "classcontroller_1_1_blacklist_controller_test.html", "classcontroller_1_1_blacklist_controller_test" ],
    [ "DashboardControllerTest", "classcontroller_1_1_dashboard_controller_test.html", "classcontroller_1_1_dashboard_controller_test" ],
    [ "MailControllerTest", "classcontroller_1_1_mail_controller_test.html", "classcontroller_1_1_mail_controller_test" ],
    [ "NotificaControllerTest", "classcontroller_1_1_notifica_controller_test.html", "classcontroller_1_1_notifica_controller_test" ]
];