var _aggiungi_prestito_controller_test_8java =
[
    [ "controller.prestitorestituzione.AggiungiPrestitoControllerTest", "classcontroller_1_1prestitorestituzione_1_1_aggiungi_prestito_controller_test.html", "classcontroller_1_1prestitorestituzione_1_1_aggiungi_prestito_controller_test" ]
];