var classcontroller_1_1catalogo_1_1_aggiungi_libro_controller =
[
    [ "buttonInitialize", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller.html#a0a95a3707891255ba880532b9b3ad96f", null ],
    [ "initialize", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller.html#afaaa8a031faae4dac2b7a51409d27a2e", null ],
    [ "settingForm", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller.html#ac6ff77a99acf5ee544832c839e5f3ae8", null ],
    [ "updateAutori", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller.html#ad9a1b440a1087ccdfdc3aaaa6346bc9a", null ]
];