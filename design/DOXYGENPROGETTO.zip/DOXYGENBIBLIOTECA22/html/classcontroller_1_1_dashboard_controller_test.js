var classcontroller_1_1_dashboard_controller_test =
[
    [ "start", "classcontroller_1_1_dashboard_controller_test.html#acb1d10a603214fc6f9e027546c066e88", null ],
    [ "tearDown", "classcontroller_1_1_dashboard_controller_test.html#a2f346bf693485a135112d401f0615be6", null ],
    [ "testAperturaModificaPassword", "classcontroller_1_1_dashboard_controller_test.html#a08ed0afd34d4d8cf76f6e0831a6d2a55", null ],
    [ "testBottoneBackup", "classcontroller_1_1_dashboard_controller_test.html#aeaa43e1776ec2f13a2c8559f09a17cc6", null ],
    [ "testLogout", "classcontroller_1_1_dashboard_controller_test.html#a15f2372de1a0211aea61354176715b66", null ],
    [ "testNavigazioneCatalogo", "classcontroller_1_1_dashboard_controller_test.html#a1e720c8b0b0059b12b5a9d1ee7905d29", null ],
    [ "testStatisticheDashboard", "classcontroller_1_1_dashboard_controller_test.html#acd1f294c52f5aab662958f4fe0b0f812", null ]
];