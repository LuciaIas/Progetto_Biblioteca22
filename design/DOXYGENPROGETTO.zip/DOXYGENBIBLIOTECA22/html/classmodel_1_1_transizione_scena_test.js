var classmodel_1_1_transizione_scena_test =
[
    [ "start", "classmodel_1_1_transizione_scena_test.html#ac18c5e07b8f35b6a8f906d59590fed35", null ],
    [ "testSwitchSceneEffect_FileInesistente", "classmodel_1_1_transizione_scena_test.html#ad6aaa85f0a5cbf9469fc791115e2ecd5", null ],
    [ "testSwitchSceneEffect_Successo", "classmodel_1_1_transizione_scena_test.html#a49158ec6ed0ef018b52f3a24a61ae98e", null ]
];