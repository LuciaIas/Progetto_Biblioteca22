var classcontroller_1_1utenti_1_1_modifica_utente_controller_test =
[
    [ "resetData", "classcontroller_1_1utenti_1_1_modifica_utente_controller_test.html#a272b2de59d768cd1b37e094bcc2b3fc6", null ],
    [ "start", "classcontroller_1_1utenti_1_1_modifica_utente_controller_test.html#a48000614a4ca60686b77bd7655c65c50", null ],
    [ "testAnnulla", "classcontroller_1_1utenti_1_1_modifica_utente_controller_test.html#afae47579ccd798a03d9f77103252211f", null ],
    [ "testCampiVuoti", "classcontroller_1_1utenti_1_1_modifica_utente_controller_test.html#a1e9fd22dc4b9148668d297c016325174", null ],
    [ "testEmailNonValida", "classcontroller_1_1utenti_1_1_modifica_utente_controller_test.html#a47ae709f9a2b880ddb580ab7d0fbd623", null ],
    [ "testInizializzazioneCorretta", "classcontroller_1_1utenti_1_1_modifica_utente_controller_test.html#a2a9eed46b7651a82825d323e0fe75730", null ],
    [ "testModificaConSuccesso", "classcontroller_1_1utenti_1_1_modifica_utente_controller_test.html#a0e0a7878d97e7f57d21d185eac94713f", null ]
];