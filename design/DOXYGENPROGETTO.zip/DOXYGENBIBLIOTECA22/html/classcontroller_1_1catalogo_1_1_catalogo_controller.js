var classcontroller_1_1catalogo_1_1_catalogo_controller =
[
    [ "initialize", "classcontroller_1_1catalogo_1_1_catalogo_controller.html#a6fc7ff7638405b598572df1845a3528e", null ],
    [ "launchAggiungiLibroForm", "classcontroller_1_1catalogo_1_1_catalogo_controller.html#a519ba53e4dede7c9320e38ea6377f69d", null ],
    [ "searchFunction", "classcontroller_1_1catalogo_1_1_catalogo_controller.html#a35149b08de3777a26c35bdd4bcebb66c", null ],
    [ "updateCatalogo", "classcontroller_1_1catalogo_1_1_catalogo_controller.html#a78a02da85caeefc1faffe8cf41e65dd4", null ]
];