var classcontroller_1_1catalogo_1_1_aggiungi_libro_controller_test =
[
    [ "start", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller_test.html#a6f9666459a4767ac667a40fd449dd198", null ],
    [ "tearDown", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller_test.html#a05e502ba575a46f89c42d88a39c52073", null ],
    [ "testInserimentoLibroCorretto", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller_test.html#a4822b23b7dd903b13e3951de80608627", null ],
    [ "testIsbnCorto", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller_test.html#ae7d1a8f6719880837358a7af38970db1", null ],
    [ "testIsbnDuplicato", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller_test.html#ae24e5a15e0fbcb90934ceabb45ed995a", null ],
    [ "testIsbnNonNumerico", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller_test.html#a7d85369f4b5c1f36661b0e49b232e1a9", null ]
];