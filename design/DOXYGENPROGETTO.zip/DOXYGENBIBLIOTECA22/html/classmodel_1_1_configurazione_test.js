var classmodel_1_1_configurazione_test =
[
    [ "pulisciConfigurazione", "classmodel_1_1_configurazione_test.html#a6ef9377e80c19d8456a30e54e3ba7ed6", null ],
    [ "testConfigurazioneEmail", "classmodel_1_1_configurazione_test.html#a972c43a7d6b9165f7375833b20e7e032", null ],
    [ "testDefaultEmailNull", "classmodel_1_1_configurazione_test.html#ac7bcf751a2738239900b7d13ab741cbf", null ],
    [ "testDefaultOrari", "classmodel_1_1_configurazione_test.html#a6665e3e7ea4c751b1ad738d9b31e5372", null ],
    [ "testDefaultValoriNumerici", "classmodel_1_1_configurazione_test.html#a94eed52b26646db21e8d4525404e0864", null ],
    [ "testErroreFormatoNumero", "classmodel_1_1_configurazione_test.html#ad054afd430542400c3d6db87f0ed3ec0", null ],
    [ "testOrariPersonalizzati", "classmodel_1_1_configurazione_test.html#a0c4bec8cd85ef7cf223c49d71e51e3fc", null ],
    [ "testValoriCaricatiCorrettamente", "classmodel_1_1_configurazione_test.html#ace9c056d11c4db0fd4eb6f6d3a5a02ad", null ]
];