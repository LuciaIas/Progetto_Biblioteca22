var classmodel_1_1servizi_1_1_operazioni_giornaliere_test =
[
    [ "setUp", "classmodel_1_1servizi_1_1_operazioni_giornaliere_test.html#abc0e4d6b7cab95b7d29664dcb3811174", null ],
    [ "tearDown", "classmodel_1_1servizi_1_1_operazioni_giornaliere_test.html#aaad25e0e5a1755fe58e55a89ba8a9d88", null ],
    [ "testCalcolaRitardoVersoMezzanotte", "classmodel_1_1servizi_1_1_operazioni_giornaliere_test.html#a0ac27ee673795940b136eceff7d7ec64", null ],
    [ "testControlliAutomatici_IgnoraNonScaduti", "classmodel_1_1servizi_1_1_operazioni_giornaliere_test.html#a77cf521d75e4f7e91eb2220741e37efb", null ],
    [ "testControlliAutomatici_RilevaRitardo", "classmodel_1_1servizi_1_1_operazioni_giornaliere_test.html#a1a9c5b333c26a8edca969a6ece0681ec", null ],
    [ "testStopScheduler", "classmodel_1_1servizi_1_1_operazioni_giornaliere_test.html#a3b8b382e00831124a5664943d7d80cec", null ]
];