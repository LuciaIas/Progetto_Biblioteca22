var _email_invia_8java =
[
    [ "model.servizi.EmailInvia", "classmodel_1_1servizi_1_1_email_invia.html", null ]
];