var classcontroller_1_1_accesso_controller_test =
[
    [ "setUpDB", "classcontroller_1_1_accesso_controller_test.html#a3c9e374883db395e317dc4782f18c98f", null ],
    [ "start", "classcontroller_1_1_accesso_controller_test.html#a2935ecfafc20093d262ca69834f3bd84", null ],
    [ "tearDown", "classcontroller_1_1_accesso_controller_test.html#a002c53a41b8890d3f44257b38004df58", null ],
    [ "testLoginFallito", "classcontroller_1_1_accesso_controller_test.html#adb4da5ecefd84e23c5a61546ff8d7e98", null ],
    [ "testLoginRiuscito", "classcontroller_1_1_accesso_controller_test.html#aefade98c8a8527a8bdb1ffc9d7b23bc5", null ],
    [ "testRegistrazioneRiuscita", "classcontroller_1_1_accesso_controller_test.html#a5baebb093570d97b3af79c426ee86b45", null ]
];