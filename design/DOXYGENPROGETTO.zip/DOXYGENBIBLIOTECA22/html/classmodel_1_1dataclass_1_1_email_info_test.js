var classmodel_1_1dataclass_1_1_email_info_test =
[
    [ "testCostruttoreEGetters", "classmodel_1_1dataclass_1_1_email_info_test.html#ad9c188e3349db48e9443c6f05fbc6d73", null ],
    [ "testToString", "classmodel_1_1dataclass_1_1_email_info_test.html#afe67e5e772c79bd6bff0bf707827a4e1", null ],
    [ "testValoriNull", "classmodel_1_1dataclass_1_1_email_info_test.html#a420b7adfeb2bca2c84551c78c53b4e16", null ]
];