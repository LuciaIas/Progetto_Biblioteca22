var classcontroller_1_1_notifica_controller =
[
    [ "initialize", "classcontroller_1_1_notifica_controller.html#a4c6d58bd94b7578ee4a3dc458cb989c0", null ]
];