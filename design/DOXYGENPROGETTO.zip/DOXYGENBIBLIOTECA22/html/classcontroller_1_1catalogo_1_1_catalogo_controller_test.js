var classcontroller_1_1catalogo_1_1_catalogo_controller_test =
[
    [ "start", "classcontroller_1_1catalogo_1_1_catalogo_controller_test.html#ab013c2096ba7387b45c48ce284d6946a", null ],
    [ "testAggiungiCopia", "classcontroller_1_1catalogo_1_1_catalogo_controller_test.html#a07021732f61d710e4a42820f513346a1", null ],
    [ "testAperturaFinestraModifica", "classcontroller_1_1catalogo_1_1_catalogo_controller_test.html#a7cadd3f51f140bfc8bda6a475d7e4ba1", null ],
    [ "testEliminaLibro", "classcontroller_1_1catalogo_1_1_catalogo_controller_test.html#ae7b3f2121707d5c1e8f61de2a6c7b1b0", null ],
    [ "testRicercaPerIsbn", "classcontroller_1_1catalogo_1_1_catalogo_controller_test.html#a2916f23b1c89611ff105e9ca55132a03", null ],
    [ "testRicercaPerTitolo", "classcontroller_1_1catalogo_1_1_catalogo_controller_test.html#a478f7a1ec378ac9b8050dd51400c52c9", null ],
    [ "testRicercaVuotaReset", "classcontroller_1_1catalogo_1_1_catalogo_controller_test.html#acc33b7a21bf3704dfeff31f619bdf57f", null ],
    [ "testRimuoviCopia", "classcontroller_1_1catalogo_1_1_catalogo_controller_test.html#a82a61b3282c483e8646bd600452be365", null ],
    [ "testVisualizzazioneIniziale", "classcontroller_1_1catalogo_1_1_catalogo_controller_test.html#adb6284bd9c76db124853e89e09a8b45f", null ]
];