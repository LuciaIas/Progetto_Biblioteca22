var _data_base_8java =
[
    [ "model.servizi.DataBase", "classmodel_1_1servizi_1_1_data_base.html", null ]
];