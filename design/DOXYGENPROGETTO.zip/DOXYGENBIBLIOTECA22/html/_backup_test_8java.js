var _backup_test_8java =
[
    [ "model.servizi.BackupTest", "classmodel_1_1servizi_1_1_backup_test.html", "classmodel_1_1servizi_1_1_backup_test" ]
];