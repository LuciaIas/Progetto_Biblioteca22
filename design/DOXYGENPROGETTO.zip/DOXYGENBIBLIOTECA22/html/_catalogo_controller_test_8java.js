var _catalogo_controller_test_8java =
[
    [ "controller.catalogo.CatalogoControllerTest", "classcontroller_1_1catalogo_1_1_catalogo_controller_test.html", "classcontroller_1_1catalogo_1_1_catalogo_controller_test" ]
];