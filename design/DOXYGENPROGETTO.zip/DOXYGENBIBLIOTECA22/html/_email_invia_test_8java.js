var _email_invia_test_8java =
[
    [ "model.servizi.EmailInviaTest", "classmodel_1_1servizi_1_1_email_invia_test.html", "classmodel_1_1servizi_1_1_email_invia_test" ]
];