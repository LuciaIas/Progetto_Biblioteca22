var classcontroller_1_1utenti_1_1_aggiungi_utente_controller =
[
    [ "buttonInitialize", "classcontroller_1_1utenti_1_1_aggiungi_utente_controller.html#a513f4f71413b226a34460e69dc3a4b05", null ],
    [ "initialize", "classcontroller_1_1utenti_1_1_aggiungi_utente_controller.html#a9dcc0c9b2af232131ba66944664adc93", null ]
];