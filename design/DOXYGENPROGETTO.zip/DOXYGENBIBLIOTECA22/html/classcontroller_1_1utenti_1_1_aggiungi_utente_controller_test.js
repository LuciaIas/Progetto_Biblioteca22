var classcontroller_1_1utenti_1_1_aggiungi_utente_controller_test =
[
    [ "resetData", "classcontroller_1_1utenti_1_1_aggiungi_utente_controller_test.html#a4ccbc81fe09db243b5e875aaf312d19f", null ],
    [ "start", "classcontroller_1_1utenti_1_1_aggiungi_utente_controller_test.html#a584731b1d8949724c80adba47eef0425", null ],
    [ "testAnnullaChiudeFinestra", "classcontroller_1_1utenti_1_1_aggiungi_utente_controller_test.html#a6c00ffc01bc28cc1015dc0d027e28a1c", null ],
    [ "testCampiVuoti", "classcontroller_1_1utenti_1_1_aggiungi_utente_controller_test.html#a94032272b1dc41b496dd372eafd94359", null ],
    [ "testEmailNonValida", "classcontroller_1_1utenti_1_1_aggiungi_utente_controller_test.html#aafc9e4c910870561ac3b230490164458", null ],
    [ "testInserimentoCorretto", "classcontroller_1_1utenti_1_1_aggiungi_utente_controller_test.html#abac2178c8c31b4028f0718bf1cd06105", null ],
    [ "testMatricolaDuplicata", "classcontroller_1_1utenti_1_1_aggiungi_utente_controller_test.html#aeeb8320cf87ee156f3e49407b109ebea", null ],
    [ "testMatricolaLunghezzaErrata", "classcontroller_1_1utenti_1_1_aggiungi_utente_controller_test.html#a88ae55ef2c5e5b5b9bf34194059d352f", null ],
    [ "testMatricolaNonNumerica", "classcontroller_1_1utenti_1_1_aggiungi_utente_controller_test.html#a5e3e064cc11c3e388e02c2a702117081", null ]
];