var dir_3bddd487bba94c1cbc94e3ae69a63060 =
[
    [ "dataclass", "dir_9b138b308818385cde66b8a00cea5900.html", "dir_9b138b308818385cde66b8a00cea5900" ],
    [ "servizi", "dir_163c20edd935f803cc4be2e5d78dff15.html", "dir_163c20edd935f803cc4be2e5d78dff15" ],
    [ "ConfigurazioneTest.java", "_configurazione_test_8java.html", "_configurazione_test_8java" ],
    [ "TransizioneScenaTest.java", "_transizione_scena_test_8java.html", "_transizione_scena_test_8java" ]
];