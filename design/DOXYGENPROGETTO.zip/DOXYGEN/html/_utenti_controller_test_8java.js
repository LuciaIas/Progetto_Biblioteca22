var _utenti_controller_test_8java =
[
    [ "controller.utenti.UtentiControllerTest", "classcontroller_1_1utenti_1_1_utenti_controller_test.html", "classcontroller_1_1utenti_1_1_utenti_controller_test" ]
];