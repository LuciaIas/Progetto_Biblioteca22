var _utente_8java =
[
    [ "model.dataclass.Utente", "classmodel_1_1dataclass_1_1_utente.html", "classmodel_1_1dataclass_1_1_utente" ]
];