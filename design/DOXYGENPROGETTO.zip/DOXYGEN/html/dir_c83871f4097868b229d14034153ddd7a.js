var dir_c83871f4097868b229d14034153ddd7a =
[
    [ "AggiungiLibroController.java", "_aggiungi_libro_controller_8java.html", "_aggiungi_libro_controller_8java" ],
    [ "CatalogoController.java", "_catalogo_controller_8java.html", "_catalogo_controller_8java" ],
    [ "ModificaLibroController.java", "_modifica_libro_controller_8java.html", "_modifica_libro_controller_8java" ]
];