var dir_5a4157b34d323b9766e61ce8e94c9f76 =
[
    [ "dataclass", "dir_e0fbd27e17cbbf93156a4ead886f7bb1.html", "dir_e0fbd27e17cbbf93156a4ead886f7bb1" ],
    [ "servizi", "dir_daa4d3039620edecbf96fc99e0963f94.html", "dir_daa4d3039620edecbf96fc99e0963f94" ],
    [ "Configurazione.java", "_configurazione_8java.html", "_configurazione_8java" ],
    [ "TransizioneScena.java", "_transizione_scena_8java.html", "_transizione_scena_8java" ]
];