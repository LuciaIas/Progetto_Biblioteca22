var namespacemodel_1_1servizi =
[
    [ "Backup", "classmodel_1_1servizi_1_1_backup.html", null ],
    [ "Catalogo", "classmodel_1_1servizi_1_1_catalogo.html", "classmodel_1_1servizi_1_1_catalogo" ],
    [ "ControlloFormato", "classmodel_1_1servizi_1_1_controllo_formato.html", null ],
    [ "DataBase", "classmodel_1_1servizi_1_1_data_base.html", null ],
    [ "EmailInvia", "classmodel_1_1servizi_1_1_email_invia.html", null ],
    [ "EmailLegge", "classmodel_1_1servizi_1_1_email_legge.html", null ],
    [ "OperazioniGiornaliere", "classmodel_1_1servizi_1_1_operazioni_giornaliere.html", null ],
    [ "Prestito", "classmodel_1_1servizi_1_1_prestito.html", "classmodel_1_1servizi_1_1_prestito" ],
    [ "BackupTest", "classmodel_1_1servizi_1_1_backup_test.html", "classmodel_1_1servizi_1_1_backup_test" ],
    [ "CatalogoTest", "classmodel_1_1servizi_1_1_catalogo_test.html", "classmodel_1_1servizi_1_1_catalogo_test" ],
    [ "ControlloFormatoTest", "classmodel_1_1servizi_1_1_controllo_formato_test.html", "classmodel_1_1servizi_1_1_controllo_formato_test" ],
    [ "DataBaseTest", "classmodel_1_1servizi_1_1_data_base_test.html", "classmodel_1_1servizi_1_1_data_base_test" ],
    [ "EmailInviaTest", "classmodel_1_1servizi_1_1_email_invia_test.html", "classmodel_1_1servizi_1_1_email_invia_test" ],
    [ "EmailLeggeTest", "classmodel_1_1servizi_1_1_email_legge_test.html", "classmodel_1_1servizi_1_1_email_legge_test" ],
    [ "OperazioniGiornaliereTest", "classmodel_1_1servizi_1_1_operazioni_giornaliere_test.html", "classmodel_1_1servizi_1_1_operazioni_giornaliere_test" ],
    [ "PrestitoTest", "classmodel_1_1servizi_1_1_prestito_test.html", "classmodel_1_1servizi_1_1_prestito_test" ]
];