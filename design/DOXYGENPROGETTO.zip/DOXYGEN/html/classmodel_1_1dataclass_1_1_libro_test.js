var classmodel_1_1dataclass_1_1_libro_test =
[
    [ "testCompareTo", "classmodel_1_1dataclass_1_1_libro_test.html#a3c84adc63f6a9eb89cd296d83c42ee21", null ],
    [ "testCompareToConTitoloNull", "classmodel_1_1dataclass_1_1_libro_test.html#acf94e518c114eec069a38cc935e566a9", null ],
    [ "testCostruttoreEGetters", "classmodel_1_1dataclass_1_1_libro_test.html#a394af9f555ea7bf034d92532af1c3294", null ],
    [ "testGestioneListaAutori", "classmodel_1_1dataclass_1_1_libro_test.html#a9019a9066ed80472e1d52d8680ce1ec1", null ],
    [ "testSetters", "classmodel_1_1dataclass_1_1_libro_test.html#a847db548d8579e32aac69f4d93cb233c", null ]
];