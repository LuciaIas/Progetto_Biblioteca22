var dir_361bf0ed982a42f6a9a63f6f1a9e668d =
[
    [ "AggiungiPrestitoControllerTest.java", "_aggiungi_prestito_controller_test_8java.html", "_aggiungi_prestito_controller_test_8java" ],
    [ "PrestitoRestituzioneControllerTest.java", "_prestito_restituzione_controller_test_8java.html", "_prestito_restituzione_controller_test_8java" ]
];