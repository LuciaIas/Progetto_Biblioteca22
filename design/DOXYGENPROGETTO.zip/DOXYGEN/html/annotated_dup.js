var annotated_dup =
[
    [ "controller", "namespacecontroller.html", [
      [ "catalogo", "namespacecontroller_1_1catalogo.html", [
        [ "AggiungiLibroController", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller.html", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller" ],
        [ "CatalogoController", "classcontroller_1_1catalogo_1_1_catalogo_controller.html", "classcontroller_1_1catalogo_1_1_catalogo_controller" ],
        [ "ModificaLibroController", "classcontroller_1_1catalogo_1_1_modifica_libro_controller.html", "classcontroller_1_1catalogo_1_1_modifica_libro_controller" ],
        [ "AggiungiLibroControllerTest", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller_test.html", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller_test" ],
        [ "CatalogoControllerTest", "classcontroller_1_1catalogo_1_1_catalogo_controller_test.html", "classcontroller_1_1catalogo_1_1_catalogo_controller_test" ],
        [ "ModificaLibroControllerTest", "classcontroller_1_1catalogo_1_1_modifica_libro_controller_test.html", "classcontroller_1_1catalogo_1_1_modifica_libro_controller_test" ]
      ] ],
      [ "modificapassword", "namespacecontroller_1_1modificapassword.html", [
        [ "CambioPasswordController", "classcontroller_1_1modificapassword_1_1_cambio_password_controller.html", "classcontroller_1_1modificapassword_1_1_cambio_password_controller" ],
        [ "InserisciPasswordModificaController", "classcontroller_1_1modificapassword_1_1_inserisci_password_modifica_controller.html", "classcontroller_1_1modificapassword_1_1_inserisci_password_modifica_controller" ],
        [ "CambioPasswordControllerTest", "classcontroller_1_1modificapassword_1_1_cambio_password_controller_test.html", "classcontroller_1_1modificapassword_1_1_cambio_password_controller_test" ],
        [ "InserisciPasswordModificaControllerTest", "classcontroller_1_1modificapassword_1_1_inserisci_password_modifica_controller_test.html", "classcontroller_1_1modificapassword_1_1_inserisci_password_modifica_controller_test" ]
      ] ],
      [ "prestitorestituzione", "namespacecontroller_1_1prestitorestituzione.html", [
        [ "AggiungiPrestitoController", "classcontroller_1_1prestitorestituzione_1_1_aggiungi_prestito_controller.html", "classcontroller_1_1prestitorestituzione_1_1_aggiungi_prestito_controller" ],
        [ "PrestitoRestituzioneController", "classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller.html", "classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller" ],
        [ "AggiungiPrestitoControllerTest", "classcontroller_1_1prestitorestituzione_1_1_aggiungi_prestito_controller_test.html", "classcontroller_1_1prestitorestituzione_1_1_aggiungi_prestito_controller_test" ],
        [ "PrestitoRestituzioneControllerTest", "classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller_test.html", "classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller_test" ]
      ] ],
      [ "utenti", "namespacecontroller_1_1utenti.html", [
        [ "AggiungiUtenteController", "classcontroller_1_1utenti_1_1_aggiungi_utente_controller.html", "classcontroller_1_1utenti_1_1_aggiungi_utente_controller" ],
        [ "ModificaUtenteController", "classcontroller_1_1utenti_1_1_modifica_utente_controller.html", "classcontroller_1_1utenti_1_1_modifica_utente_controller" ],
        [ "UtentiController", "classcontroller_1_1utenti_1_1_utenti_controller.html", "classcontroller_1_1utenti_1_1_utenti_controller" ],
        [ "AggiungiUtenteControllerTest", "classcontroller_1_1utenti_1_1_aggiungi_utente_controller_test.html", "classcontroller_1_1utenti_1_1_aggiungi_utente_controller_test" ],
        [ "ModificaUtenteControllerTest", "classcontroller_1_1utenti_1_1_modifica_utente_controller_test.html", "classcontroller_1_1utenti_1_1_modifica_utente_controller_test" ],
        [ "UtentiControllerTest", "classcontroller_1_1utenti_1_1_utenti_controller_test.html", "classcontroller_1_1utenti_1_1_utenti_controller_test" ]
      ] ],
      [ "AccessoController", "classcontroller_1_1_accesso_controller.html", "classcontroller_1_1_accesso_controller" ],
      [ "BlacklistController", "classcontroller_1_1_blacklist_controller.html", "classcontroller_1_1_blacklist_controller" ],
      [ "DashboardController", "classcontroller_1_1_dashboard_controller.html", "classcontroller_1_1_dashboard_controller" ],
      [ "MailController", "classcontroller_1_1_mail_controller.html", "classcontroller_1_1_mail_controller" ],
      [ "NotificaController", "classcontroller_1_1_notifica_controller.html", "classcontroller_1_1_notifica_controller" ],
      [ "AccessoControllerTest", "classcontroller_1_1_accesso_controller_test.html", "classcontroller_1_1_accesso_controller_test" ],
      [ "BlacklistControllerTest", "classcontroller_1_1_blacklist_controller_test.html", "classcontroller_1_1_blacklist_controller_test" ],
      [ "DashboardControllerTest", "classcontroller_1_1_dashboard_controller_test.html", "classcontroller_1_1_dashboard_controller_test" ],
      [ "MailControllerTest", "classcontroller_1_1_mail_controller_test.html", "classcontroller_1_1_mail_controller_test" ],
      [ "NotificaControllerTest", "classcontroller_1_1_notifica_controller_test.html", "classcontroller_1_1_notifica_controller_test" ]
    ] ],
    [ "main", "namespacemain.html", [
      [ "Main", "classmain_1_1_main.html", "classmain_1_1_main" ]
    ] ],
    [ "model", "namespacemodel.html", [
      [ "dataclass", "namespacemodel_1_1dataclass.html", [
        [ "Autore", "classmodel_1_1dataclass_1_1_autore.html", "classmodel_1_1dataclass_1_1_autore" ],
        [ "EmailInfo", "classmodel_1_1dataclass_1_1_email_info.html", "classmodel_1_1dataclass_1_1_email_info" ],
        [ "Libro", "classmodel_1_1dataclass_1_1_libro.html", "classmodel_1_1dataclass_1_1_libro" ],
        [ "Stato", "enummodel_1_1dataclass_1_1_stato.html", "enummodel_1_1dataclass_1_1_stato" ],
        [ "Utente", "classmodel_1_1dataclass_1_1_utente.html", "classmodel_1_1dataclass_1_1_utente" ],
        [ "AutoreTest", "classmodel_1_1dataclass_1_1_autore_test.html", "classmodel_1_1dataclass_1_1_autore_test" ],
        [ "EmailInfoTest", "classmodel_1_1dataclass_1_1_email_info_test.html", "classmodel_1_1dataclass_1_1_email_info_test" ],
        [ "LibroTest", "classmodel_1_1dataclass_1_1_libro_test.html", "classmodel_1_1dataclass_1_1_libro_test" ],
        [ "UtenteTest", "classmodel_1_1dataclass_1_1_utente_test.html", "classmodel_1_1dataclass_1_1_utente_test" ]
      ] ],
      [ "servizi", "namespacemodel_1_1servizi.html", [
        [ "Backup", "classmodel_1_1servizi_1_1_backup.html", null ],
        [ "Catalogo", "classmodel_1_1servizi_1_1_catalogo.html", "classmodel_1_1servizi_1_1_catalogo" ],
        [ "ControlloFormato", "classmodel_1_1servizi_1_1_controllo_formato.html", null ],
        [ "DataBase", "classmodel_1_1servizi_1_1_data_base.html", null ],
        [ "EmailInvia", "classmodel_1_1servizi_1_1_email_invia.html", null ],
        [ "EmailLegge", "classmodel_1_1servizi_1_1_email_legge.html", null ],
        [ "OperazioniGiornaliere", "classmodel_1_1servizi_1_1_operazioni_giornaliere.html", null ],
        [ "Prestito", "classmodel_1_1servizi_1_1_prestito.html", "classmodel_1_1servizi_1_1_prestito" ],
        [ "BackupTest", "classmodel_1_1servizi_1_1_backup_test.html", "classmodel_1_1servizi_1_1_backup_test" ],
        [ "CatalogoTest", "classmodel_1_1servizi_1_1_catalogo_test.html", "classmodel_1_1servizi_1_1_catalogo_test" ],
        [ "ControlloFormatoTest", "classmodel_1_1servizi_1_1_controllo_formato_test.html", "classmodel_1_1servizi_1_1_controllo_formato_test" ],
        [ "DataBaseTest", "classmodel_1_1servizi_1_1_data_base_test.html", "classmodel_1_1servizi_1_1_data_base_test" ],
        [ "EmailInviaTest", "classmodel_1_1servizi_1_1_email_invia_test.html", "classmodel_1_1servizi_1_1_email_invia_test" ],
        [ "EmailLeggeTest", "classmodel_1_1servizi_1_1_email_legge_test.html", "classmodel_1_1servizi_1_1_email_legge_test" ],
        [ "OperazioniGiornaliereTest", "classmodel_1_1servizi_1_1_operazioni_giornaliere_test.html", "classmodel_1_1servizi_1_1_operazioni_giornaliere_test" ],
        [ "PrestitoTest", "classmodel_1_1servizi_1_1_prestito_test.html", "classmodel_1_1servizi_1_1_prestito_test" ]
      ] ],
      [ "Configurazione", "classmodel_1_1_configurazione.html", null ],
      [ "TransizioneScena", "classmodel_1_1_transizione_scena.html", null ],
      [ "ConfigurazioneTest", "classmodel_1_1_configurazione_test.html", "classmodel_1_1_configurazione_test" ],
      [ "TransizioneScenaTest", "classmodel_1_1_transizione_scena_test.html", "classmodel_1_1_transizione_scena_test" ]
    ] ]
];