var namespacecontroller_1_1catalogo =
[
    [ "AggiungiLibroController", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller.html", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller" ],
    [ "CatalogoController", "classcontroller_1_1catalogo_1_1_catalogo_controller.html", "classcontroller_1_1catalogo_1_1_catalogo_controller" ],
    [ "ModificaLibroController", "classcontroller_1_1catalogo_1_1_modifica_libro_controller.html", "classcontroller_1_1catalogo_1_1_modifica_libro_controller" ],
    [ "AggiungiLibroControllerTest", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller_test.html", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller_test" ],
    [ "CatalogoControllerTest", "classcontroller_1_1catalogo_1_1_catalogo_controller_test.html", "classcontroller_1_1catalogo_1_1_catalogo_controller_test" ],
    [ "ModificaLibroControllerTest", "classcontroller_1_1catalogo_1_1_modifica_libro_controller_test.html", "classcontroller_1_1catalogo_1_1_modifica_libro_controller_test" ]
];