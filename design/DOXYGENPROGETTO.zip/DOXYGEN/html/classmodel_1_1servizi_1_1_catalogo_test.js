var classmodel_1_1servizi_1_1_catalogo_test =
[
    [ "setUp", "classmodel_1_1servizi_1_1_catalogo_test.html#a1d464fc1721c2aa6116a4b01b54097cb", null ],
    [ "testAggiungiLibro", "classmodel_1_1servizi_1_1_catalogo_test.html#a5ab5f6b2d95e84da31c7672a6dd3e056", null ],
    [ "testCercaPerAutore", "classmodel_1_1servizi_1_1_catalogo_test.html#a25dae3b0b5e963aed5af7c01ff36848b", null ],
    [ "testCercaPerAutore_NessunLibro", "classmodel_1_1servizi_1_1_catalogo_test.html#aaae7d78289ee7d6a800abaa4cd856b9e", null ],
    [ "testCercaPerIsbn_NonTrovato", "classmodel_1_1servizi_1_1_catalogo_test.html#a0d565d7ee75e2dc937cecb80875f3aae", null ],
    [ "testCercaPerIsbn_Trovato", "classmodel_1_1servizi_1_1_catalogo_test.html#acc555c521a1da2d7776ed17bee9f67ab", null ],
    [ "testCercaPerTitolo_CaseInsensitive", "classmodel_1_1servizi_1_1_catalogo_test.html#a3c645057c1c98b57a1699fdbda57da5d", null ],
    [ "testCercaPerTitolo_NessunRisultato", "classmodel_1_1servizi_1_1_catalogo_test.html#a11a109265ac8e6d30995036f67b3e1fb", null ],
    [ "testCercaPerTitolo_Parziale", "classmodel_1_1servizi_1_1_catalogo_test.html#a715e1c8ae71a33df8c71f831167452ed", null ],
    [ "testRimuoviLibro", "classmodel_1_1servizi_1_1_catalogo_test.html#aed48015fd34f646378be6f8234b0791d", null ],
    [ "testSortAlfabetico", "classmodel_1_1servizi_1_1_catalogo_test.html#aa6cba5dbc31a7a07357c518fdc77ea93", null ],
    [ "testSortCaseInsensitive", "classmodel_1_1servizi_1_1_catalogo_test.html#a57e647b494ccf20042982a0c29b41b4f", null ]
];