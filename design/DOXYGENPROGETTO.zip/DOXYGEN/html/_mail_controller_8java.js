var _mail_controller_8java =
[
    [ "controller.MailController", "classcontroller_1_1_mail_controller.html", "classcontroller_1_1_mail_controller" ]
];