var classmodel_1_1servizi_1_1_email_legge_test =
[
    [ "setUp", "classmodel_1_1servizi_1_1_email_legge_test.html#a7ec37a12a1ce29a1d4aaef81ccedf49d", null ],
    [ "tearDown", "classmodel_1_1servizi_1_1_email_legge_test.html#aa9df3a2d60bb95d89a768853702b2ce6", null ],
    [ "testLeggiPostaInviata", "classmodel_1_1servizi_1_1_email_legge_test.html#ae66e3d33c412cbc8554465826ca7ac13", null ]
];