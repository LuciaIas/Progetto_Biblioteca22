var classcontroller_1_1catalogo_1_1_modifica_libro_controller_test =
[
    [ "resetData", "classcontroller_1_1catalogo_1_1_modifica_libro_controller_test.html#a7fd17f73a6fd4f052be51bbcd594b669", null ],
    [ "start", "classcontroller_1_1catalogo_1_1_modifica_libro_controller_test.html#a87cab6953e00be32b6949e976acf4948", null ],
    [ "testAggiungiNuovoAutore", "classcontroller_1_1catalogo_1_1_modifica_libro_controller_test.html#a1e0c0764e63c6ec15ae2568a3f59600d", null ],
    [ "testCaricamentoDatiIniziali", "classcontroller_1_1catalogo_1_1_modifica_libro_controller_test.html#a91c33bf4512114e1c7776717398cc32c", null ],
    [ "testModificaDatiBase", "classcontroller_1_1catalogo_1_1_modifica_libro_controller_test.html#a1130e50424ba52306a43aa23bdf46bb3", null ],
    [ "testRimuoviCopertina", "classcontroller_1_1catalogo_1_1_modifica_libro_controller_test.html#ab3b777737029a96fadf47286f64e745f", null ]
];