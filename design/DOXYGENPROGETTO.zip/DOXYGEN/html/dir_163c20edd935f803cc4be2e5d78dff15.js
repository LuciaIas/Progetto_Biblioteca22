var dir_163c20edd935f803cc4be2e5d78dff15 =
[
    [ "BackupTest.java", "_backup_test_8java.html", "_backup_test_8java" ],
    [ "CatalogoTest.java", "_catalogo_test_8java.html", "_catalogo_test_8java" ],
    [ "ControlloFormatoTest.java", "_controllo_formato_test_8java.html", "_controllo_formato_test_8java" ],
    [ "DataBaseTest.java", "_data_base_test_8java.html", "_data_base_test_8java" ],
    [ "EmailInviaTest.java", "_email_invia_test_8java.html", "_email_invia_test_8java" ],
    [ "EmailLeggeTest.java", "_email_legge_test_8java.html", "_email_legge_test_8java" ],
    [ "OperazioniGiornaliereTest.java", "_operazioni_giornaliere_test_8java.html", "_operazioni_giornaliere_test_8java" ],
    [ "PrestitoTest.java", "_prestito_test_8java.html", "_prestito_test_8java" ]
];