var searchData=
[
  ['aggiungiautore_0',['aggiungiAutore',['../classmodel_1_1servizi_1_1_data_base.html#a50be880ae0abd6290a4b91726b961251',1,'model::servizi::DataBase']]],
  ['aggiungilibro_1',['aggiungiLibro',['../classmodel_1_1servizi_1_1_catalogo.html#a80c8ae7627e0f7aa800fef5bf6793a2e',1,'model.servizi.Catalogo.aggiungiLibro()'],['../classmodel_1_1servizi_1_1_data_base.html#ae7cade3e4c0c3adc2e87533ada523026',1,'model.servizi.DataBase.aggiungiLibro(Libro l)']]],
  ['aggiungiprestito_2',['aggiungiPrestito',['../classmodel_1_1servizi_1_1_data_base.html#a66edfcea859f7d15805c4db1f955fd80',1,'model::servizi::DataBase']]],
  ['aggiungiutente_3',['aggiungiUtente',['../classmodel_1_1servizi_1_1_data_base.html#a9590c42bf4c6a519afbf65f408074cb2',1,'model::servizi::DataBase']]],
  ['autore_4',['Autore',['../classmodel_1_1dataclass_1_1_autore.html#af34ce603d1ace7300cd1a13c02966a1d',1,'model::dataclass::Autore']]],
  ['avviataskdimezzanotte_5',['avviaTaskDiMezzanotte',['../classmodel_1_1servizi_1_1_operazioni_giornaliere.html#ab49dcf496ecc6e40edd419f0d850b33b',1,'model::servizi::OperazioniGiornaliere']]]
];
