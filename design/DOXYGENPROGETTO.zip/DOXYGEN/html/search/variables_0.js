var searchData=
[
  ['attivo_0',['ATTIVO',['../enummodel_1_1dataclass_1_1_stato.html#a95012a0a30ce68f9dc302f0e17146ab9',1,'model::dataclass::Stato']]]
];
