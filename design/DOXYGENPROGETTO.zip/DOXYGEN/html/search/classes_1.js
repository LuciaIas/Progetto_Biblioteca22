var searchData=
[
  ['backup_0',['Backup',['../classmodel_1_1servizi_1_1_backup.html',1,'model::servizi']]],
  ['backuptest_1',['BackupTest',['../classmodel_1_1servizi_1_1_backup_test.html',1,'model::servizi']]],
  ['blacklistcontroller_2',['BlacklistController',['../classcontroller_1_1_blacklist_controller.html',1,'controller']]],
  ['blacklistcontrollertest_3',['BlacklistControllerTest',['../classcontroller_1_1_blacklist_controller_test.html',1,'controller']]]
];
