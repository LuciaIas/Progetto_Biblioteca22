var searchData=
[
  ['passrec_0',['PassRec',['../classcontroller_1_1_dashboard_controller.html#ab4a5ff22a426919e109118f2489bfccc',1,'controller::DashboardController']]],
  ['prorogato_1',['PROROGATO',['../enummodel_1_1dataclass_1_1_stato.html#a59c921aec5783f46f7f380a2ad54025e',1,'model::dataclass::Stato']]]
];
