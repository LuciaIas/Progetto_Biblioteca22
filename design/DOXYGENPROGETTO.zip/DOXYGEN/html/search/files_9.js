var searchData=
[
  ['operazionigiornaliere_2ejava_0',['OperazioniGiornaliere.java',['../_operazioni_giornaliere_8java.html',1,'']]],
  ['operazionigiornalieretest_2ejava_1',['OperazioniGiornaliereTest.java',['../_operazioni_giornaliere_test_8java.html',1,'']]]
];
