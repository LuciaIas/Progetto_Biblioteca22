var searchData=
[
  ['main_0',['main',['../namespacemain.html',1,'']]],
  ['model_1',['model',['../namespacemodel.html',1,'']]],
  ['model_3a_3adataclass_2',['dataclass',['../namespacemodel_1_1dataclass.html',1,'model']]],
  ['model_3a_3aservizi_3',['servizi',['../namespacemodel_1_1servizi.html',1,'model']]]
];
