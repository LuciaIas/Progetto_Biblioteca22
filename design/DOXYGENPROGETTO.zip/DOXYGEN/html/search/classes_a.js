var searchData=
[
  ['prestito_0',['Prestito',['../classmodel_1_1servizi_1_1_prestito.html',1,'model::servizi']]],
  ['prestitorestituzionecontroller_1',['PrestitoRestituzioneController',['../classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller.html',1,'controller::prestitorestituzione']]],
  ['prestitorestituzionecontrollertest_2',['PrestitoRestituzioneControllerTest',['../classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller_test.html',1,'controller::prestitorestituzione']]],
  ['prestitotest_3',['PrestitoTest',['../classmodel_1_1servizi_1_1_prestito_test.html',1,'model::servizi']]]
];
