var searchData=
[
  ['open_5ftime_0',['open_time',['../classmain_1_1_main.html#a8697a39831c0d526da3b7e6dcc5caf88',1,'main::Main']]],
  ['operazionigiornaliere_1',['OperazioniGiornaliere',['../classmodel_1_1servizi_1_1_operazioni_giornaliere.html',1,'model::servizi']]],
  ['operazionigiornaliere_2ejava_2',['OperazioniGiornaliere.java',['../_operazioni_giornaliere_8java.html',1,'']]],
  ['operazionigiornalieretest_3',['OperazioniGiornaliereTest',['../classmodel_1_1servizi_1_1_operazioni_giornaliere_test.html',1,'model::servizi']]],
  ['operazionigiornalieretest_2ejava_4',['OperazioniGiornaliereTest.java',['../_operazioni_giornaliere_test_8java.html',1,'']]]
];
