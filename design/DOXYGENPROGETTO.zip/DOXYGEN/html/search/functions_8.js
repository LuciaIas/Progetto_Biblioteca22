var searchData=
[
  ['preliminaryfunctions_0',['PreliminaryFunctions',['../classmain_1_1_main.html#aad67ca43f06a02ca0ebefd9ae3df031d',1,'main::Main']]],
  ['prestito_1',['Prestito',['../classmodel_1_1servizi_1_1_prestito.html#a5c07c4b76a5dec594172e79432801dee',1,'model::servizi::Prestito']]],
  ['prorogaprestito_2',['prorogaPrestito',['../classmodel_1_1servizi_1_1_data_base.html#a4c9c6b2f6218b09a76dbf019ac005797',1,'model::servizi::DataBase']]],
  ['pulisciconfigurazione_3',['pulisciConfigurazione',['../classmodel_1_1_configurazione_test.html#a6ef9377e80c19d8456a30e54e3ba7ed6',1,'model::ConfigurazioneTest']]]
];
