var searchData=
[
  ['unsetblacklisted_0',['unsetBlackListed',['../classmodel_1_1servizi_1_1_data_base.html#a95cfc9e7d2c20fdd645d9e542e251717',1,'model::servizi::DataBase']]],
  ['updateautori_1',['updateAutori',['../classcontroller_1_1catalogo_1_1_aggiungi_libro_controller.html#ad9a1b440a1087ccdfdc3aaaa6346bc9a',1,'controller.catalogo.AggiungiLibroController.updateAutori()'],['../classcontroller_1_1catalogo_1_1_modifica_libro_controller.html#a60b63ad38e27c6aa3e6d434a6d04be3e',1,'controller.catalogo.ModificaLibroController.updateAutori()']]],
  ['updatecatalogo_2',['updateCatalogo',['../classcontroller_1_1catalogo_1_1_catalogo_controller.html#a78a02da85caeefc1faffe8cf41e65dd4',1,'controller::catalogo::CatalogoController']]],
  ['updateprestiti_3',['updatePrestiti',['../classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller.html#a955612a65c5ae24911a5e743eba90cd3',1,'controller::prestitorestituzione::PrestitoRestituzioneController']]],
  ['updateutentilist_4',['updateUtentiList',['../classcontroller_1_1_blacklist_controller.html#aa92bd7020d8af88ccd6707e9eeabe7df',1,'controller.BlacklistController.updateUtentiList()'],['../classcontroller_1_1utenti_1_1_utenti_controller.html#a2b77d33ef90fa5b910e130e63f232511',1,'controller.utenti.UtentiController.updateUtentiList()']]],
  ['utente_5',['Utente',['../classmodel_1_1dataclass_1_1_utente.html',1,'model.dataclass.Utente'],['../classmodel_1_1dataclass_1_1_utente.html#aab1b56bb2bcf86812284b1c893bafd60',1,'model.dataclass.Utente.Utente()']]],
  ['utente_2ejava_6',['Utente.java',['../_utente_8java.html',1,'']]],
  ['utentetest_7',['UtenteTest',['../classmodel_1_1dataclass_1_1_utente_test.html',1,'model::dataclass']]],
  ['utentetest_2ejava_8',['UtenteTest.java',['../_utente_test_8java.html',1,'']]],
  ['utenticontroller_9',['UtentiController',['../classcontroller_1_1utenti_1_1_utenti_controller.html',1,'controller::utenti']]],
  ['utenticontroller_2ejava_10',['UtentiController.java',['../_utenti_controller_8java.html',1,'']]],
  ['utenticontrollertest_11',['UtentiControllerTest',['../classcontroller_1_1utenti_1_1_utenti_controller_test.html',1,'controller::utenti']]],
  ['utenticontrollertest_2ejava_12',['UtentiControllerTest.java',['../_utenti_controller_test_8java.html',1,'']]]
];
