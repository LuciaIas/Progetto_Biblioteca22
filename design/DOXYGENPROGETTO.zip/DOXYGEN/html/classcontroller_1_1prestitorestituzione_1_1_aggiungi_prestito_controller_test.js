var classcontroller_1_1prestitorestituzione_1_1_aggiungi_prestito_controller_test =
[
    [ "resetData", "classcontroller_1_1prestitorestituzione_1_1_aggiungi_prestito_controller_test.html#aa967bed6d720606c2dcb47fae87c7743", null ],
    [ "start", "classcontroller_1_1prestitorestituzione_1_1_aggiungi_prestito_controller_test.html#a8faca18950936399b594b93f982c56b2", null ],
    [ "testDateErrate", "classcontroller_1_1prestitorestituzione_1_1_aggiungi_prestito_controller_test.html#a95a957a881326a22b57de96feaebf511", null ],
    [ "testLibroEsaurito", "classcontroller_1_1prestitorestituzione_1_1_aggiungi_prestito_controller_test.html#ad46cafe7d0085c9f7cbe3f5cbd733c72", null ],
    [ "testSalvataggioConSuccesso", "classcontroller_1_1prestitorestituzione_1_1_aggiungi_prestito_controller_test.html#a5ec00022234b7ee22c777cb1727142d6", null ],
    [ "testSalvataggioSenzaValidazione", "classcontroller_1_1prestitorestituzione_1_1_aggiungi_prestito_controller_test.html#af3dc25ff5c002933956edcc48339825c", null ],
    [ "testUtenteBloccato", "classcontroller_1_1prestitorestituzione_1_1_aggiungi_prestito_controller_test.html#af39eba6e64a1370a96b0f7d5c4c78e89", null ],
    [ "testValidazioneIsbnErrato", "classcontroller_1_1prestitorestituzione_1_1_aggiungi_prestito_controller_test.html#a0bda03eef10e3cce0b518ef522fb018b", null ],
    [ "testValidazioneMatricolaErrata", "classcontroller_1_1prestitorestituzione_1_1_aggiungi_prestito_controller_test.html#aa721b7fe25aaafc4fa4929d20b153a04", null ],
    [ "testValidazioneOk", "classcontroller_1_1prestitorestituzione_1_1_aggiungi_prestito_controller_test.html#a166b7d0a050b1567da0ad0522b5ce9df", null ]
];