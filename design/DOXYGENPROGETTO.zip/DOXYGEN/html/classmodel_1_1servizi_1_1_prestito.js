var classmodel_1_1servizi_1_1_prestito =
[
    [ "Prestito", "classmodel_1_1servizi_1_1_prestito.html#a5c07c4b76a5dec594172e79432801dee", null ],
    [ "getData_scadenza", "classmodel_1_1servizi_1_1_prestito.html#ad1135b66cbf8e09ee0146cf9b92b50f6", null ],
    [ "getInizio_prestito", "classmodel_1_1servizi_1_1_prestito.html#afcf0534d5090d04e207b72ddd7998251", null ],
    [ "getIsbn", "classmodel_1_1servizi_1_1_prestito.html#a28c5c967d4ea2e994d8c77d42b7eb04f", null ],
    [ "getMatricola", "classmodel_1_1servizi_1_1_prestito.html#a49301afea2e0d70641dfec96acb1ba81", null ],
    [ "getRestituzione", "classmodel_1_1servizi_1_1_prestito.html#a47bae4acf05ece68a0588b4c62dd1e69", null ],
    [ "getStato", "classmodel_1_1servizi_1_1_prestito.html#a4e61e98fce8b6a95f2bdac18c518ff7a", null ],
    [ "setData_scadenza", "classmodel_1_1servizi_1_1_prestito.html#aab0801ba2e0bb808c709d6613775cf62", null ],
    [ "setInizio_prestito", "classmodel_1_1servizi_1_1_prestito.html#a54f89d4d0ee838852cdee073e4d27a99", null ],
    [ "setIsbn", "classmodel_1_1servizi_1_1_prestito.html#aeef6a422932e3bfdcfb7aa23fd82ea48", null ],
    [ "setMatricola", "classmodel_1_1servizi_1_1_prestito.html#af3f3e81d054b210a80c5d1529ea44b9a", null ],
    [ "setRestituzione", "classmodel_1_1servizi_1_1_prestito.html#a74dc90c87e17001ac3fe3c5b83449ac6", null ],
    [ "setStato", "classmodel_1_1servizi_1_1_prestito.html#ae34a140a55dc9bd103bd35fe11e19856", null ],
    [ "toString", "classmodel_1_1servizi_1_1_prestito.html#a7b65bb38d2fbccaff3edbc3cc803bc36", null ]
];