var _aggiungi_libro_controller_test_8java =
[
    [ "controller.catalogo.AggiungiLibroControllerTest", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller_test.html", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller_test" ]
];