var _dashboard_controller_test_8java =
[
    [ "controller.DashboardControllerTest", "classcontroller_1_1_dashboard_controller_test.html", "classcontroller_1_1_dashboard_controller_test" ]
];