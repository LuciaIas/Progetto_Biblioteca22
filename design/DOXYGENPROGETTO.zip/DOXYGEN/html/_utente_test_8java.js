var _utente_test_8java =
[
    [ "model.dataclass.UtenteTest", "classmodel_1_1dataclass_1_1_utente_test.html", "classmodel_1_1dataclass_1_1_utente_test" ]
];