var _notifica_controller_test_8java =
[
    [ "controller.NotificaControllerTest", "classcontroller_1_1_notifica_controller_test.html", "classcontroller_1_1_notifica_controller_test" ]
];