var _stato_8java =
[
    [ "model.dataclass.Stato", "enummodel_1_1dataclass_1_1_stato.html", "enummodel_1_1dataclass_1_1_stato" ]
];