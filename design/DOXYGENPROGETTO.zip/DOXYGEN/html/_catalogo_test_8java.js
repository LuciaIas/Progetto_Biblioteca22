var _catalogo_test_8java =
[
    [ "model.servizi.CatalogoTest", "classmodel_1_1servizi_1_1_catalogo_test.html", "classmodel_1_1servizi_1_1_catalogo_test" ]
];