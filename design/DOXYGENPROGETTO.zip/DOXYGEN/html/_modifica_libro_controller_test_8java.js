var _modifica_libro_controller_test_8java =
[
    [ "controller.catalogo.ModificaLibroControllerTest", "classcontroller_1_1catalogo_1_1_modifica_libro_controller_test.html", "classcontroller_1_1catalogo_1_1_modifica_libro_controller_test" ]
];