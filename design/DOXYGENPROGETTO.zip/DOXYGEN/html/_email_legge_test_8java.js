var _email_legge_test_8java =
[
    [ "model.servizi.EmailLeggeTest", "classmodel_1_1servizi_1_1_email_legge_test.html", "classmodel_1_1servizi_1_1_email_legge_test" ]
];