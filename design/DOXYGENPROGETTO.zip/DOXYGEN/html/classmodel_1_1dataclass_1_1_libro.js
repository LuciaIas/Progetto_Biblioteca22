var classmodel_1_1dataclass_1_1_libro =
[
    [ "Libro", "classmodel_1_1dataclass_1_1_libro.html#a7c1acf29650a23ef08941ced9ab73415", null ],
    [ "compareTo", "classmodel_1_1dataclass_1_1_libro.html#aa2683d5dffeea179e3a6b558477d2fa9", null ],
    [ "getAnno_pubblicazione", "classmodel_1_1dataclass_1_1_libro.html#ada485b4752468a412052c7be3a7a6dd1", null ],
    [ "getAutori", "classmodel_1_1dataclass_1_1_libro.html#ac9348a51a94e5d7b4a44e93dd0ced1d1", null ],
    [ "getEditore", "classmodel_1_1dataclass_1_1_libro.html#ac7a9a759ffc325cff8d18627a263eaa7", null ],
    [ "getIsbn", "classmodel_1_1dataclass_1_1_libro.html#a2359f087e61e0b01aecf111fd894b1a9", null ],
    [ "getNumero_copieDisponibili", "classmodel_1_1dataclass_1_1_libro.html#a736ac3a216ded495bca8cef894038549", null ],
    [ "getTitolo", "classmodel_1_1dataclass_1_1_libro.html#afeb246a1a2f74ebc5a5bca29fc936aae", null ],
    [ "getUrl", "classmodel_1_1dataclass_1_1_libro.html#a5883de42e20122e3c8d553d250ca63db", null ],
    [ "setAnno_pubblicazione", "classmodel_1_1dataclass_1_1_libro.html#a31ef1398f018d37ddd3b980b2f79e6b7", null ],
    [ "setAutori", "classmodel_1_1dataclass_1_1_libro.html#a05d9a3fd9538415b8e4dfe63015c79cc", null ],
    [ "setEditore", "classmodel_1_1dataclass_1_1_libro.html#aeeb4c4d1de9d8ec44024635a1afb8a1f", null ],
    [ "setIsbn", "classmodel_1_1dataclass_1_1_libro.html#afd67b7810540758dbec5757de81bb04f", null ],
    [ "setNumero_copieDisponibili", "classmodel_1_1dataclass_1_1_libro.html#a169413c88500674eda144ab56d729238", null ],
    [ "setTitolo", "classmodel_1_1dataclass_1_1_libro.html#a3d77c147c9bda6127d6aba54457e6f41", null ],
    [ "setUrl", "classmodel_1_1dataclass_1_1_libro.html#a7440c16c2ce11e6f273de66870adbc24", null ],
    [ "toString", "classmodel_1_1dataclass_1_1_libro.html#aa628f0d39352aff8dcb62c55733918d9", null ]
];