var _operazioni_giornaliere_test_8java =
[
    [ "model.servizi.OperazioniGiornaliereTest", "classmodel_1_1servizi_1_1_operazioni_giornaliere_test.html", "classmodel_1_1servizi_1_1_operazioni_giornaliere_test" ]
];