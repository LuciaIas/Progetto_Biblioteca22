var _aggiungi_utente_controller_test_8java =
[
    [ "controller.utenti.AggiungiUtenteControllerTest", "classcontroller_1_1utenti_1_1_aggiungi_utente_controller_test.html", "classcontroller_1_1utenti_1_1_aggiungi_utente_controller_test" ]
];