var namespacemodel_1_1dataclass =
[
    [ "Autore", "classmodel_1_1dataclass_1_1_autore.html", "classmodel_1_1dataclass_1_1_autore" ],
    [ "EmailInfo", "classmodel_1_1dataclass_1_1_email_info.html", "classmodel_1_1dataclass_1_1_email_info" ],
    [ "Libro", "classmodel_1_1dataclass_1_1_libro.html", "classmodel_1_1dataclass_1_1_libro" ],
    [ "Stato", "enummodel_1_1dataclass_1_1_stato.html", "enummodel_1_1dataclass_1_1_stato" ],
    [ "Utente", "classmodel_1_1dataclass_1_1_utente.html", "classmodel_1_1dataclass_1_1_utente" ],
    [ "AutoreTest", "classmodel_1_1dataclass_1_1_autore_test.html", "classmodel_1_1dataclass_1_1_autore_test" ],
    [ "EmailInfoTest", "classmodel_1_1dataclass_1_1_email_info_test.html", "classmodel_1_1dataclass_1_1_email_info_test" ],
    [ "LibroTest", "classmodel_1_1dataclass_1_1_libro_test.html", "classmodel_1_1dataclass_1_1_libro_test" ],
    [ "UtenteTest", "classmodel_1_1dataclass_1_1_utente_test.html", "classmodel_1_1dataclass_1_1_utente_test" ]
];