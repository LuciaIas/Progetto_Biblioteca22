var classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller_test =
[
    [ "resetData", "classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller_test.html#af48c02b754cdf0d688c0584e942d3df7", null ],
    [ "start", "classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller_test.html#afce18d85226e09f1acb5dab16083c294", null ],
    [ "testApreNuovoPrestito", "classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller_test.html#ad9d3fa90551c03aa01d5e3354e1b2f21", null ],
    [ "testCaricamentoIniziale", "classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller_test.html#ab7ef57fe8cf90ba31a6ee40966adf718", null ],
    [ "testFiltroInRitardo", "classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller_test.html#a880f74d09d26157535a9e74bf1c8da95", null ],
    [ "testInvioEmail", "classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller_test.html#aec31ae8faac82efd52a654c84c5f6d30", null ],
    [ "testRestituzione", "classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller_test.html#ae1662f7c1cd84d05e9a4ceac038b5a0c", null ],
    [ "testRicercaLibro", "classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller_test.html#a35b124712fc76741f66dd5ecedae639b", null ]
];