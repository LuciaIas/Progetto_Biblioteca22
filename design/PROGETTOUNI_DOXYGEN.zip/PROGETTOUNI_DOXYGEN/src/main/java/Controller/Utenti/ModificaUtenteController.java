/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller.Utenti;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * @brief Controller per la modifica dei dati di un utente esistente.
 * * Questa classe gestisce il form per aggiornare le informazioni personali
 * (Nome, Cognome, Email) di uno studente già registrato.
 * La matricola non è modificabile e viene passata staticamente prima dell'apertura della finestra.
 * * @author GRUPPO22
 * @version 1.0
 */
public class ModificaUtenteController {
    
    /** * @name Dati Identificativi
     * Campi per la visualizzazione dell'utente target.
     */
    ///@{
    @FXML private Label lblMatricola;       ///< Label che mostra la matricola dell'utente (non modificabile).
    
    /** @brief Variabile statica utilizzata per passare la matricola dell'utente da modificare dalla view precedente. */
    public static String matricola;
    ///@}

    /** * @name Input Modificabili
     * Campi di testo per i nuovi dati.
     */
    ///@{
    @FXML private TextField txtNome;        ///< Campo per il nuovo nome.
    @FXML private TextField txtCognome;     ///< Campo per il nuovo cognome.
    @FXML private TextField txtEmail;       ///< Campo per la nuova email.
    ///@}

    /** * @name Azioni
     * Bottoni per confermare o annullare.
     */
    ///@{
    @FXML private Button btnSalva;          ///< Bottone per salvare le modifiche.
    @FXML private Button btnAnnulla;        ///< Bottone per chiudere la finestra.
    ///@}

    /**
     * @brief Inizializza il controller.
     * * Questo metodo viene chiamato all'apertura della finestra.
     * 1. Imposta il testo della label matricola usando la variabile statica.
     * 2. Configura il tasto **Annulla** per chiudere lo stage.
     * 3. Configura il tasto **Salva** con la logica di validazione:
     * - Verifica che nome e cognome non siano vuoti.
     * - Verifica il formato dell'email.
     * - Se i dati sono validi, chiama `Model.DataBase.ModifyUser`.
     * - Mostra un Alert di conferma e chiude la finestra.
     */
    @FXML
    public void initialize(){

    }
    
}