package Controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

/**
 * @brief Controller per la visualizzazione delle notifiche di ritardo.
 * * Questa classe gestisce una semplice notifica(é una view) che calcola e mostra all'utente
 * il numero totale di prestiti che si trovano attualmente nello stato "IN_RITARDO".
 * * @author GRUPPO22
 * @version 1.0
 */
public class NotifyController {
    
    /** @brief Label che visualizza il messaggio di testo con il conteggio dei ritardi. */
    @FXML
    private Label numRit;
    
    /**
     * @brief Inizializza il controller.
     * Viene chiamato automaticamente al caricamento della view.
     * Scorre la lista dei prestiti dal Database, conta quanti sono in stato `IN_RITARDO`
     * e aggiorna il testo della Label con il conteggio e un messaggio di suggerimento.
     */
    @FXML
    public void initialize(){
    
    }
}