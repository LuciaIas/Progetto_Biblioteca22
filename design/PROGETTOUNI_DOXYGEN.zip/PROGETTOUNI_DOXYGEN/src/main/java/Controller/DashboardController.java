package Controller;


import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

/**
 * @brief Controller principale della Dashboard.
 * * Questa classe gestisce la schermata principale dell'applicazione (Dashboard).
 * Si occupa di:
 * - Navigazione tra le varie sezioni (Catalogo, Utenti, Prestiti, Blacklist, Mail).
 * - Visualizzazione delle statistiche in tempo reale (numero libri, prestiti attivi, utenti, ritardi).
 * - Gestione delle funzionalità di sistema (Logout, Backup, Modifica Password), resi presenti in tutte le sezioni.
 * - Gestione del lancio delle varie sezione sulla destra della sidebar.
 * * @author GRUPPO22
 * @version 1.0
 */
public class DashboardController {
    
    /** * @name Pulsanti di Navigazione
     * Pulsanti presenti nella sidebar per cambiare sezione.
     */
    ///@{
    @FXML private Button DashboardButton;           ///< Bottone per tornare alla Home.
    @FXML private Button CatalogoLibriButton;       ///< Bottone per accedere al Catalogo Libri.
    @FXML private Button utentiButton;              ///< Bottone per la gestione Utenti.
    @FXML private Button PrestitiRestituzioniButton;///< Bottone per la gestione Prestiti/Restituzioni.
    @FXML private Button BLButton;                  ///< Bottone per visualizzare la Blacklist.
    @FXML private Button mailButton;                ///< Bottone per la sezione invio Mail/Avvisi.
    ///@}

    /** * @name Label Statistiche
     * Label che mostrano i conteggi in tempo reale.
     */
    ///@{
    @FXML private Label numLibri;       ///< Mostra il numero totale di libri nel catalogo.
    @FXML private Label numLoanAttivi;  ///< Mostra il numero di prestiti attualmente in corso.
    @FXML private Label numUsers;       ///< Mostra il numero totale di utenti registrati.
    @FXML private Label numScaduti;     ///< Mostra il numero di prestiti in ritardo.
    ///@}

    /** * @name Componenti di Layout
     * Contenitori per la struttura della pagina.
     */
    ///@{
    @FXML private VBox DashboardBox;            ///< Contenitore verticale della dashboard.
    @FXML private ScrollPane DashboardScrollPane; ///< Pannello scorrevole principale.
    @FXML private BorderPane HomeBorderPane;    ///< Layout principale: il contenuto cambia nella regione CENTER.
    ///@}

    /** * @name Pulsanti di Sistema
     * Funzionalità amministrative e di sessione.
     */
    ///@{
    @FXML private Button LogoutButton;  ///< Effettua il logout e torna alla schermata di accesso.
    @FXML private Button modPassButton; ///< Apre la view per modificare la password.
    @FXML private Button BackupButton;  ///< Avvia la procedura di backup dei dati dove aver fatto scegliere la destinazione.
    ///@}
    


    
    /**
     * @brief Inizializza il controller.
     * Viene chiamato automaticamente al caricamento della view.
     * Inizializza la lista dei bottoni, configura le azioni (ButtonInitialize)
     * e carica i dati nelle label (LabelInitialize).
     */
    @FXML
    public void initialize(){

    }
    
    /**
     * @brief Carica e visualizza le statistiche del sistema.
     * Interroga il `DataBase` per ottenere:
     * - Numero totale libri.
     * - Prestiti attivi (Stato ATTIVO, PROROGATO, IN_RITARDO).
     * - Numero utenti totali.
     * - Prestiti specificamente in ritardo.
     */
    public void LabelInitialize(){

    }

    /**
     * @brief Configura le azioni (EventHandler) per tutti i pulsanti.
     * Gestisce:
     * - **Backup:** Apre un DirectoryChooser e chiama `BackupService`.
     * - **Modifica Password:** Apre un nuovo Stage per inserire la vecchia password.
     * - **Logout:** Torna alla schermata di Login (`Access.fxml`).
     * - **Navigazione:** Carica i file FXML relativi (Catalogo, Utenti, ecc.) 
     * all'interno del HomeBorderPane e aggiorna lo stile del menu.
     */
    public void ButtonInitialize(){

    }
    
    /**
     * @brief Gestisce lo stile visivo dei pulsanti della sidebar.
     * Rimuove la classe CSS "active" da tutti i pulsanti e la assegna solo a quello cliccato.
     * Questo fornisce un feedback visivo all'utente su quale sezione è attualmente visualizzata.
     * * @param bottoneAttivo Il pulsante che è stato appena cliccato.
     */
    private void evidenziaBottone(Button bottoneAttivo) {

    }
    
}