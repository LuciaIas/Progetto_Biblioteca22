/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 * @brief Controller per la verifica della password attuale.
 * * Questa classe gestisce la finestra che richiede al bibliotecario di inserire
 * la propria password corrente prima di poter accedere alla schermata di modifica password.
 * * @author GRUPPO22
 * @version 1.0
 */
public class InserisciPasswordPerModificaController {
    
    /** * @name Input Campi
     * Campi per l'inserimento della password.
     */
    ///@{
    @FXML private PasswordField NewPass;        ///< Campo password nascosto.
    @FXML private TextField NewPassVisible;     ///< Campo password visibile.
    ///@}

    /** * @name Controlli UI
     * Elementi di controllo dell'interfaccia.
     */
    ///@{
    @FXML private CheckBox CheckShowPass;       ///< Checkbox per mostrare/nascondere la password.
    @FXML private Button BtnSalva;              ///< Bottone per confermare.
    @FXML private Label BtnAnnulla;             ///< Label usata come bottone per annullare.
    ///@}

    /**
     * @brief Inizializza il controller.
     * Imposta i listener per la checkbox e per i bottoni.
     */
    @FXML
    public void initialize(){

    }
    
    /**
     * @brief Configura le funzioni dei pulsanti Salva e Annulla.
     * Controlla se la password è vuota o errata tramite Database.
     * Se corretta, apre la finestra di cambio password.
     */
    public void SetButtonFunction(){

    }
    
    /**
     * @brief Configura la CheckBox per mostrare/nascondere la password.
     */
    public void SetCheckBox(){

    }
    
    /**
     * @brief Gestisce la visibilità dei campi password.
     * Alterna tra PasswordField e TextField copiando il contenuto.
     * @param yes True per mostrare la password, False per nasconderla.
     */
    public void ShowPassword(boolean yes){
        
    }
}