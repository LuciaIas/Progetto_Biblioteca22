/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Model.DataClass.Autore;
import Model.DataClass.Libro;
import Model.DataClass.Stato;
import Model.DataClass.User;
import java.sql.Connection;
import java.util.ArrayList;

/**
 * @brief Classe per la gestione del Database.
 * * Questa classe gestisce la connessione al database MySQL ("Biblioteca") e fornisce
 * tutti i metodi statici necessari per eseguire operazioni CRUD (Create, Read, Update, Delete)
 * su Libri, Autori, Utenti, Prestiti e Bibliotecario.
 * Gestisce anche la sicurezza delle password tramite hashing SHA-256 (fornita da app, non da database).
 * * @author GRUPPO22
 * @version 
 */
public class DataBase {
    
    /** @brief Oggetto Connection per la gestione della sessione SQL. */
    static Connection conn;
    
    /** @brief Nome del database a cui connettersi. */
    static String DB_name="Biblioteca";
    
    
    /**
     * @brief Inizializza la connessione al Database.
     * Utilizza il driver JDBC per connettersi a localhost con credenziali root/vuota.
     */
    public static void DBInitialize(){

    }
    
    /** * @name Gestione Bibliotecario (Login & Registrazione)
     * Metodi per la gestione dell'account amministratore e sicurezza.
     */
    ///@{

    /**
     * @brief Registra un nuovo bibliotecario nel sistema.
     * Controlla se esiste già un bibliotecario. Se no, esegue l'hashing della password (SHA-256)
     * e la salva nel database.
     * @param password La password in chiaro da salvare.
     * @return true se l'inserimento ha successo, false altrimenti.
     */
    public static boolean InsertBibliotecario(String password){
        return false;
    }

    /**
     * @brief Verifica se esiste un bibliotecario registrato.
     * @return true se la tabella bibliotecario non è vuota, false altrimenti.
     */
    public static boolean CheckIfExistsBibliotecario(){
        return false;
    }
    
    /**
     * @brief Rimuove l'account del bibliotecario (Reset).
     * @return true se la cancellazione avviene con successo, false altrimenti.
     */
    public static boolean RemoveBibliotecario(){
        return false;
    }
    
    /**
     * @brief Verifica le credenziali di accesso.
     * Esegue l'hash della password fornita e la confronta con quella salvata nel DB.
     * @param password La password in chiaro inserita dall'utente.
     * @return true se la password corrisponde, false altrimenti.
     */
    public static boolean CheckPasswordBibliotecario(String password){
        return false;
    }
    ///@}
    
    /** * @name Gestione Libri e Catalogo
     * Metodi per recuperare, aggiungere, modificare ed eliminare libri.
     */
    ///@{

    /**
     * @brief Recupera l'intero catalogo dei libri.
     * Esegue una join logica caricando prima i libri, poi gli autori e infine associando
     * gli autori ai libri tramite la tabella di relazione scritto_da.
     * @return Un oggetto Catalogo contenente la lista completa e ordinata dei libri.
     */
    public static Catalogo GetCatalogo(){
        return null;
    }
    
    /**
     * @brief Aggiunge un nuovo libro al database.
     * Inserisce i dati nella tabella libri e crea le relazioni nella tabella scritto_da per gli autori.
     * @param l Oggetto Libro da inserire.
     * @return true se l'operazione ha successo, false altrimenti.
     */
    public static boolean addBook(Libro l){
        return false;
    }
    
    /**
     * @brief Cerca un libro tramite ISBN.
     * Utilizza il metodo GetCatalogo e filtra i risultati.
     * @param isbn Codice ISBN da cercare.
     * @return Oggetto Libro se trovato, altrimenti null.
     */
    public static Libro searchBook(String isbn){
        return null;
    }
    
    /**
     * @brief Modifica i dati di un libro esistente.
     * Aggiorna la tabella libri e ricrea le associazioni autori in scritto_da.
     * @param isbn ISBN originale del libro.
     * @param titolo Nuovo titolo.
     * @param editore Nuovo editore.
     * @param anno_pubblicazione Nuovo anno.
     * @param num_copie Nuovo numero di copie.
     * @param url Nuovo URL immagine.
     * @param autori Nuova lista autori.
     * @return true se l'aggiornamento riesce, false altrimenti.
     */
    public static boolean ModifyBook(String isbn,String titolo,String editore,int anno_pubblicazione,int num_copie, String url,ArrayList<Autore> autori){
        return false;
    }
    
    /**
     * @brief Rimuove un libro dal database.
     * @param isbn L'ISBN del libro da eliminare.
     * @return true se l'eliminazione ha successo, false altrimenti.
     */
    public static boolean RemoveBook(String isbn){
        return false;
    }
    
    /**
     * @brief Cerca libri in base al titolo.
     * @param titolo Il titolo (o parte di esso) da cercare.
     * @return ArrayList di libri trovati o lista vuota.
     */
    public static ArrayList<Libro> SearchUserByTitle(String titolo){
        return null;
    }
    
    /**
     * @brief Verifica se un ISBN è già presente nel database.
     * @param isbn L'ISBN da verificare.
     * @return true se presente, false altrimenti.
     */
    public static boolean isIsbnPresent(String isbn){
        return false;
    }
    
    /**
     * @brief Ottiene il numero di copie disponibili per un libro.
     * @param isbn L'ISBN del libro.
     * @return Il numero di copie (intero) o -1 in caso di errore.
     */
    public static int getNumCopieByIsbn(String isbn){
        return 0;
    }
    
    /**
     * @brief Modifica il numero di copie disponibili (incremento o decremento).
     * @param isbn Il libro da aggiornare.
     * @param add Se true incrementa di 1, se false decrementa di 1.
     * @return true se l'aggiornamento riesce, false altrimenti.
     */
    public static boolean ModifyNum_copie(String isbn,boolean add){
        return false;
    }
    ///@}

    /** * @name Gestione Autori
     * Metodi per gestire la tabella autori.
     */
    ///@{

    /**
     * @brief Recupera tutti gli autori dal database.
     * @return ArrayList di oggetti Autore o null in caso di errore.
     */
    public static ArrayList<Autore> getAutori(){
        return null;
    }

    /**
     * @brief Inserisce un nuovo autore nel database.
     * @param a L'oggetto Autore da inserire.
     * @return true se inserito correttamente, false altrimenti.
     */
    public static boolean addAutore(Autore a){
        return false;
    }
    
    /**
     * @brief Restituisce il numero totale di autori registrati.
     * @return Numero di autori (int).
     */
    public static int getNum_Autori(){
        return 0;
    }
    
    /**
     * @brief Cerca un autore tramite nome e cognome.
     * @param nome Nome dell'autore.
     * @param cognome Cognome dell'autore.
     * @return Oggetto Autore se trovato, null altrimenti.
     */
    public static Autore SearchAutorByNames(String nome,String cognome){
        return null;
    }
    
    /**
     * @brief Conta le relazioni nella tabella scritto_da.
     * Utile per controllare limiti del database.
     * @return Numero di relazioni (int).
     */
    public static int GetNumRelationsScritto_Da(){
        return 0;
    }
    ///@}

    /** * @name Gestione Utenti
     * Metodi per la gestione degli studenti iscritti.
     */
    ///@{

    /**
     * @brief Recupera la lista di tutti gli utenti.
     * @return ArrayList di User, ordinati per Cognome e Nome.
     */
    public static ArrayList<User> getUtenti(){
        return null;
    }
    
    /**
     * @brief Aggiunge un nuovo utente.
     * @param u L'oggetto User da inserire.
     * @return true se l'operazione riesce, false altrimenti.
     */
    public static boolean addUser(User u){
        return false;
    }
    
    /**
     * @brief Conta il numero totale di utenti.
     * @return Numero totale di utenti (int).
     */
    public static int getNumUser(){
        return 0;
    }
    
    /**
     * @brief Cerca un utente per matricola.
     * @param matricola La matricola da cercare.
     * @return Oggetto User se trovato, null altrimenti.
     */
    public static User searchUser(String matricola){
        return null;
    }
    
    /**
     * @brief Imposta lo stato di blocco (Blacklist) per un utente.
     * @param matricola Matricola dell'utente da bloccare.
     * @return true se l'aggiornamento riesce, false altrimenti.
     */
    public static boolean setBlackListed(String matricola){
        return false;
    }
    
    /**
     * @brief Rimuove il blocco (Blacklist) da un utente.
     * @param matricola Matricola dell'utente da sbloccare.
     * @return true se l'aggiornamento riesce, false altrimenti.
     */
    public static boolean UnsetBlackListed(String matricola){
        return false;
    }
    
    /**
     * @brief Modifica i dati di un utente.
     * @param matricola Matricola dell'utente (chiave primaria).
     * @param nome Nuovo nome.
     * @param cognome Nuovo cognome.
     * @param mail Nuova mail.
     * @return true se la modifica riesce, false altrimenti.
     */
    public static boolean ModifyUser(String matricola,String nome,String cognome,String mail){
        return false;
    }
    
    /**
     * @brief Rimuove un utente dal sistema.
     * @param matricola Matricola dell'utente da eliminare.
     * @return true se l'eliminazione riesce, false altrimenti.
     */
    public static boolean RemoveUser(String matricola){
        return false;
    }
    
    /**
     * @brief Verifica se una matricola è già presente nel sistema.
     * @param matricola La matricola da controllare.
     * @return true se presente, false altrimenti.
     */
    public static boolean isMatricolaPresent(String matricola){
        return false;
    }
    ///@}

    /** * @name Gestione Prestiti
     * Metodi per gestire le operazioni di prestito libri.
     */
    ///@{

    /**
     * @brief Recupera tutti i prestiti (attivi, ritardo, storico).
     * Converte la stringa di stato del DB nell'enum Stato.
     * @return ArrayList di oggetti Prestito.
     */
    public static ArrayList<Prestito> getPrestiti(){
        return null;
    }
    
    /**
     * @brief Aggiunge un nuovo prestito.
     * @param p Oggetto Prestito da salvare.
     * @return true se l'inserimento riesce, false altrimenti.
     */
    public static boolean addPrestito(Prestito p){
        return false;
    }
    
    /**
     * @brief Restituisce il numero totale di prestiti registrati (inclusi quelli conclusi).
     * @return Numero totale di prestiti (int).
     */
    public static int getNumLoan(){
        return 0;
    }
    
    /**
     * @brief Registra la restituzione di un libro.
     * Imposta la data di restituzione a oggi e lo stato a RESTITUITO.
     * @param isbn ISBN del libro restituito.
     * @param matricola Matricola dell'utente che restituisce.
     * @return true se l'aggiornamento riesce, false altrimenti.
     */
    public static boolean Restituisci(String isbn,String matricola){
        return false;
    }
    
    /**
     * @brief Verifica se esiste un prestito attivo per una data coppia libro-utente.
     * @param isbn ISBN del libro.
     * @param matricola Matricola dell'utente.
     * @return true se esiste un prestito, false altrimenti.
     */
    public static boolean CheckPrestito(String isbn,String matricola){
        return false;
    }
    
    /**
     * @brief Rimuove definitivamente un record di prestito dal database.
     * @param isbn ISBN del libro.
     * @param matricola Matricola dell'utente.
     * @return true se la cancellazione riesce, false altrimenti.
     */
    public static boolean RemovePrestito(String isbn,String matricola){
        return false;
    }
    
    /**
     * @brief Aggiorna lo stato di un prestito (es. da ATTIVO a IN_RITARDO).
     * @param isbn ISBN del libro.
     * @param matricola Matricola dell'utente.
     * @param stato Nuovo stato da impostare.
     * @return true se l'aggiornamento riesce, false altrimenti.
     */
    public static boolean setStatoPrestito(String isbn,String matricola, Stato stato){
        return false;
    }
    
    /**
     * @brief Proroga la scadenza di un prestito di 15 giorni.
     * @param isbn ISBN del libro.
     * @param matricola Matricola dell'utente.
     * @return true se la proroga è applicata con successo, false altrimenti.
     */
    public static boolean ProrogaPrestito(String isbn,String matricola){
        return false;
    }
    ///@}
    
}