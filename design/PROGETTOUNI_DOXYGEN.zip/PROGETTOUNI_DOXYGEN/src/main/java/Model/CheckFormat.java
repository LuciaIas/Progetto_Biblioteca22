package Model;


/**
 * @brief Classe di utilità per la validazione dei formati.
 * * Fornisce metodi statici per verificare la correttezza formale di stringhe
 * critiche come Password ed Email.
 * * @author GRUPPO22
 * @version 1.0
 */
public class CheckFormat {
    
    /**
     * @brief Verifica se una password rispetta i criteri di sicurezza.
     * * La password deve soddisfare i seguenti requisiti imposti dalla Regex:
     * - Almeno un numero (0-9).
     * - Almeno una lettera minuscola (a-z).
     * - Almeno una lettera maiuscola (A-Z).
     * - Almeno un carattere speciale tra i seguenti (@#$%^&+=!).
     * - Nessuno spazio bianco.
     * - Lunghezza minima di 8 caratteri.
     * * @param password La stringa da validare.
     * @return true se la password è sicura, false se è null o non rispetta il formato.
     */
    public static boolean CheckPasswordFormat(String password){
        return true;//true se rispetta il formato altrimenti false
    }
    
    /**
     * @brief Verifica se una stringa è un indirizzo email valido.
     * * Controlla la presenza della chiocciola (@) e del dominio separato da un punto.
     * * @param email L'indirizzo email da controllare.
     * @return true se il formato è corretto, false altrimenti.
     */
    public static boolean CheckEmailFormat(String email){
        return true;//true se rispetta il formato altrimenti false
    }
    
    
}