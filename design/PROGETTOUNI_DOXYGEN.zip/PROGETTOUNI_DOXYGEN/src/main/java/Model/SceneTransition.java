package Model;

import javafx.stage.Stage;

/**
 * @brief Classe di utilità per la gestione delle transizioni tra scene JavaFX.
 * * Questa classe fornisce metodi statici per cambiare la GUI all'interno dello Stage principale,
 * applicando effetti grafici (come la dissolvenza) e reimpostando le dimensioni della finestra.
 * * @author GRUPPO22
 * @version 1.0
 */
public class SceneTransition {

    /**
     * @brief Effettua un cambio di scena con effetto dissolvenza.
     * * @param stage Lo Stage principale dell'applicazione su cui effettuare il cambio.
     * @param fxmlPath Il percorso relativo del file FXML da caricare (es. "/View/dashboard.fxml").
     */
    public static void switchSceneEffect(Stage stage, String fxmlPath) {

    }
}