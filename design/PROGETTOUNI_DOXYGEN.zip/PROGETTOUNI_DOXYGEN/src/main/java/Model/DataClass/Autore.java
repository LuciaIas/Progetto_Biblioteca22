package Model.DataClass;

import java.time.LocalDate;

/**
 * @brief Classe modello che rappresenta un Autore.
 * * Questa classe fa da contenitore dati per le informazioni relative
 * agli autori dei libri presenti nel catalogo.
 * Memorizza dati anagrafici e statistiche sulle opere scritte.
 * * @author GRUPPO22
 * @version 1.0
 */
public class Autore {
    
    /** * @name Dati Anagrafici
     * Informazioni identificative e personali dell'autore.
     */
    ///@{
    private int id;                 ///< Identificativo univoco dell'autore nel database.
    private String nome;            ///< Nome dell'autore.
    private String cognome;         ///< Cognome dell'autore.
    private LocalDate data_nascita; ///< Data di nascita.
    private int opere_scritte;      ///< Numero totale di opere scritte dall'autore presenti nel sistema.
    ///@}



    /**
     * @brief Costruttore della classe Autore.
     * Inizializza un oggetto con i dati principali (escluso l'ID che viene assegnato in base al DB).
     * @param nome Nome dell'autore.
     * @param cognome Cognome dell'autore.
     * @param opere_scritte Numero di opere associate.
     * @param data_nascita Data di nascita.
     */
    public Autore(String nome, String cognome, int opere_scritte, LocalDate data_nascita) {

    }

    // --- GETTERS & SETTERS ---

    /**
     * @brief Restituisce l'ID dell'autore.
     * @return Intero rappresentante l'ID.
     */
    public int getId() {
        return id;
    }

    /**
     * @brief Imposta l'ID dell'autore.
     * @param id Nuovo ID da assegnare.
     */
    public void setId(int id) {

    }
    
    /**
     * @brief Restituisce il nome.
     * @return Stringa nome.
     */
    public String getNome() {
        return nome;
    }

    /**
     * @brief Imposta il nome.
     * @param nome Nuovo nome.
     */
    public void setNome(String nome) {

    }

    /**
     * @brief Restituisce il cognome.
     * @return Stringa cognome.
     */
    public String getCognome() {
        return cognome;
    }

    /**
     * @brief Imposta il cognome.
     * @param cognome Nuovo cognome.
     */
    public void setCognome(String cognome) {

    }

    /**
     * @brief Restituisce il numero di opere scritte.
     * @return Intero contatore opere.
     */
    public int getOpere_scritte() {
        return opere_scritte;
    }

    /**
     * @brief Imposta il numero di opere scritte.
     * @param opere_scritte Nuovo numero opere.
     */
    public void setOpere_scritte(int opere_scritte) {

    }

    /**
     * @brief Restituisce la data di nascita.
     * @return Oggetto LocalDate.
     */
    public LocalDate getData_nascita() {
        return data_nascita;
    }

    /**
     * @brief Imposta la data di nascita.
     * @param data_nascita Nuova data di nascita.
     */
    public void setData_nascita(LocalDate data_nascita) {

    }

    /**
     * @brief Rappresentazione testuale dell'oggetto Autore.
     * @return Stringa con i dettagli dell'autore.
     */
    @Override
    public String toString() {
        return null;
    }
    
}