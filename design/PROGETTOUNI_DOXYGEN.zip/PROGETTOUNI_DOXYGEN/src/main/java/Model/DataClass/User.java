package Model.DataClass;

import java.util.ArrayList;

/**
 * @brief Classe modello che rappresenta un Utente (Studente) del sistema.
 * * Questa classe fa da contenitore di dati per le informazioni personali dello studente
 * e per il suo stato all'interno del sistema bibliotecario (Attivo o Bloccato/Blacklisted).
 * * @author GRUPPO22
 * @version 1.0
 */
public class User {
    
    /** * @name Dati Anagrafici
     * Informazioni identificative e di contatto dell'utente.
     */
    ///@{
    private String matricola;   ///< Codice univoco identificativo.
    private String nome;        ///< Nome dell'utente.
    private String cognome;     ///< Cognome dell'utente.
    private String mail;        ///< Indirizzo email istituzionale o personale.
    ///@}

    /** * @name Stato Utente
     * Informazioni relative ai permessi e alla posizione dell'utente.
     */
    ///@{
    private boolean bloccato;   ///< Flag che indica se l'utente è nella Blacklist (true = bloccato).
    ///@}

    /**
     * @brief Costruttore della classe User.
     * Inizializza un nuovo utente con tutti i dati necessari.
     * @param matricola Matricola.
     * @param nome Nome.
     * @param cognome Cognome.
     * @param mail Email di contatto.
     * @param bloccato Stato iniziale (solitamente false alla creazione).
     */
    public User(String matricola, String nome, String cognome, String mail, boolean bloccato) {

    }

    /**
     * @brief Filtra una lista di utenti e restituisce solo quelli bloccati (Blacklist).
     * * Scorre l'array di input e seleziona gli utenti che hanno il flag `bloccato` impostato a true.
     * * @param users La lista completa degli utenti da filtrare.
     * @return Un nuovo ArrayList contenente solo gli utenti bloccati.
     */
    public static ArrayList<User> getUsersBlackListed(ArrayList<User> users){
        return null;
    }
    
    // --- GETTERS & SETTERS ---

    /**
     * @brief Restituisce la matricola.
     * @return Stringa matricola.
     */
    public String getMatricola() {
        return matricola;
    }

    /**
     * @brief Imposta la matricola.
     * @param matricola Nuova matricola.
     */
    public void setMatricola(String matricola) {

    }

    /**
     * @brief Verifica se l'utente è bloccato.
     * @return `true` se l'utente è in Blacklist, `false` se è attivo.
     */
    public boolean isBloccato() {
        return bloccato;
    }

    /**
     * @brief Imposta lo stato di blocco dell'utente.
     * @param bloccato `true` per bloccare, `false` per attivare.
     */
    public void setBloccato(boolean bloccato) {

    }

    /**
     * @brief Restituisce il nome.
     * @return Stringa nome.
     */
    public String getNome() {
        return nome;
    }

    /**
     * @brief Imposta il nome.
     * @param nome Nuovo nome.
     */
    public void setNome(String nome) {

    }

    /**
     * @brief Restituisce il cognome.
     * @return Stringa cognome.
     */
    public String getCognome() {
        return cognome;
    }

    /**
     * @brief Imposta il cognome.
     * @param cognome Nuovo cognome.
     */
    public void setCognome(String cognome) {
        
    }

    /**
     * @brief Restituisce l'indirizzo email.
     * @return Stringa email.
     */
    public String getMail() {
        return mail;
    }

    /**
     * @brief Imposta l'indirizzo email.
     * @param mail Nuova email.
     */
    public void setMail(String mail) {
 
    }

    /**
     * @brief Rappresentazione testuale dell'oggetto User.
     * @return Stringa con i dati anagrafici principali.
     */
    @Override
    public String toString() {
        return null;
    }
    
}