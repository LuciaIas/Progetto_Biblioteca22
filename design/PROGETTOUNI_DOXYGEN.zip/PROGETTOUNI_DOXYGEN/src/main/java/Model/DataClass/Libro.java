package Model.DataClass;

import java.time.Year;
import java.util.List;

/**
 * @brief Classe modello che rappresenta un Libro.
 * * Questa classe memorizza tutte le informazioni relative a un libro nel catalogo,
 * inclusi i dettagli bibliografici (ISBN, titolo, autori) e lo stato di disponibilitá (copie).
 * Implementa l'interfaccia Comparable per permettere l'ordinamento naturale alfabetico per titolo.
 * * @author GRUPPO22
 * @version 1.0
 */
public class Libro implements Comparable<Libro>{
    
    /** * @name Dati Bibliografici Principali
     * Informazioni identificative testuali del libro.
     */
    ///@{
    private String isbn;        ///< Codice identificativo univoco.
    private String titolo;      ///< Titolo del libro.
    private String editore;     ///< Casa editrice.
    private String url;         ///< URL o percorso locale dell'immagine di copertina.
    ///@}

    /** * @name Dettagli Pubblicazione e Disponibilità
     * Informazioni tecniche e quantitative.
     */
    ///@{
    private List<Autore> autori;        ///< Lista degli oggetti Autore che hanno scritto il libro.
    private Year anno_pubblicazione;    ///< Anno di pubblicazione.
    private int numero_copieDisponibili;///< Numero di copie fisiche attualmente disponibili in biblioteca.
    ///@}

    /**
     * @brief Costruttore della classe Libro.
     * Inizializza un nuovo oggetto con tutti i parametri necessari.
     * @param isbn Codice ISBN.
     * @param titolo Titolo del libro.
     * @param editore Casa editrice.
     * @param autori Lista degli autori.
     * @param anno_pubblicazione Anno di uscita.
     * @param numero_copieDisponibili Numero iniziale di copie.
     * @param url Percorso dell'immagine di copertina.
     */
    public Libro(String isbn, String titolo, String editore, List<Autore> autori, Year anno_pubblicazione, int numero_copieDisponibili, String url) {

    }

    // --- GETTERS & SETTERS ---

    /**
     * @brief Restituisce il codice ISBN.
     * @return Stringa ISBN.
     */
    public String getIsbn() {
        return isbn;
    }

    /**
     * @brief Imposta il codice ISBN.
     * @param isbn Nuovo ISBN.
     */
    public void setIsbn(String isbn) {

    }

    /**
     * @brief Restituisce il titolo del libro.
     * @return Stringa titolo.
     */
    public String getTitolo() {
        return titolo;
    }

    /**
     * @brief Imposta il titolo del libro.
     * @param titolo Nuovo titolo.
     */
    public void setTitolo(String titolo) {

    }

    /**
     * @brief Restituisce la casa editrice.
     * @return Stringa editore.
     */
    public String getEditore() {
        return editore;
    }

    /**
     * @brief Imposta la casa editrice.
     * @param editore Nuovo editore.
     */
    public void setEditore(String editore) {

    }

    /**
     * @brief Restituisce la lista degli autori.
     * @return List di oggetti Autore.
     */
    public List<Autore> getAutori() {
        return autori;
    }

    /**
     * @brief Imposta la lista degli autori.
     * @param autori Nuova lista di autori.
     */
    public void setAutori(List<Autore> autori) {

    }

    /**
     * @brief Restituisce l'anno di pubblicazione.
     * @return Oggetto Year.
     */
    public Year getAnno_pubblicazione() {
        return anno_pubblicazione;
    }

    /**
     * @brief Imposta l'anno di pubblicazione.
     * @param anno_pubblicazione Nuovo anno.
     */
    public void setAnno_pubblicazione(Year anno_pubblicazione) {

    }

    /**
     * @brief Restituisce il numero di copie disponibili.
     * @return Intero rappresentante le copie.
     */
    public int getNumero_copieDisponibili() {
        return numero_copieDisponibili;
    }

    /**
     * @brief Imposta il numero di copie disponibili.
     * @param numero_copieDisponibili Nuova quantità.
     */
    public void setNumero_copieDisponibili(int numero_copieDisponibili) {

    }

    /**
     * @brief Restituisce l'URL della copertina.
     * @return Stringa con il percorso dell'immagine.
     */
    public String getUrl() {
        return url;
    }

    /**
     * @brief Imposta l'URL della copertina.
     * @param url Nuovo percorso immagine.
     */
    public void setUrl(String url) {

    }

    /**
     * @brief Rappresentazione testuale dell'oggetto Libro.
     * @return Stringa con i dettagli principali del libro.
     */
    @Override
    public String toString() {
        return null;
    }

    /**
     * @brief Comparatore per l'ordinamento naturale dei libri.
     * Confronta due libri basandosi sul loro titolo in ordine alfabetico (lessicografico).
     * @param o Il libro da confrontare con l'istanza corrente.
     * @return Un numero negativo, zero o positivo se questo titolo è rispettivamente minore, uguale o maggiore del titolo passato.
     */
    @Override
    public int compareTo(Libro o) {
        return 0;
    }
    
}