package Model.DataClass;

/**
 * @brief Enumerazione che definisce gli stati possibili di un Prestito.
 * * Questa enum viene utilizzata per tracciare il ciclo di vita di un prestito
 * all'interno del sistema, dalla creazione alla restituzione, inclusi stati di
 * eccezione come il ritardo o l'estensione temporale.
 * * @author GRUPPO22
 * @version 1.0
 */
public enum Stato {
    
    /** @brief Il prestito è in corso e la data di scadenza non è ancora stata superata. */
    ATTIVO,
    
    /** @brief Il libro è stato restituito e il prestito è considerato concluso (storico). */
    RESTITUITO,
    
    /** @brief La durata del prestito è stata estesa (15 giorni). */
    PROROGATO,
    
    /** @brief La data di scadenza è passata e il libro non è ancora stato restituito. */
    IN_RITARDO
}