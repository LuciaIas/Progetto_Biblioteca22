package Model;

import java.util.Date;

/**
 * @brief Classe modello per le informazioni di una Email inviata.
 * * Questa classe funge da semplice contenitore di dati 
 * per memorizzare i dettagli delle email inviate dal sistema (oggetto, destinatario, data),
 * utile per la visualizzazione nello storico.
 * * @author GRUPPO22
 * @version 1.0
 */
public class EmailInfo {
    
    /** @brief Oggetto (Titolo) dell'email. */
    private String oggetto;
    
    /** @brief Indirizzo email del destinatario. */
    private String destinatario;
    
    /** @brief Data e ora di invio. */
    private Date dataInvio;

    /**
     * @brief Costruttore della classe.
     * Inizializza un nuovo oggetto con tutti i dettagli dell'email.
     * @param oggetto L'oggetto o titolo dell'email.
     * @param destinatario L'indirizzo email a cui è stato inviato il messaggio.
     * @param dataInvio La data e l'ora dell'invio.
     */
    public EmailInfo(String oggetto, String destinatario, Date dataInvio) {

    }

    // Getter per leggerli dopo

    /**
     * @brief Restituisce l'oggetto dell'email.
     * @return Stringa contenente l'oggetto.
     */
    public String getOggetto() { 
        return oggetto; 
    }

    /**
     * @brief Restituisce il destinatario dell'email.
     * @return Stringa contenente l'indirizzo email.
     */
    public String getDestinatario() { 
        return destinatario; 
    }

    /**
     * @brief Restituisce la data di invio.
     * @return Oggetto Date rappresentante il momento dell'invio.
     */
    public Date getDataInvio() {
        return dataInvio; 
    }
    
    /**
     * @brief Restituisce una rappresentazione testuale dell'oggetto.
     * Utile per il debug o per visualizzazioni rapide in console.
     * @return Stringa formattata con data, destinatario e oggetto.
     */
    @Override
    public String toString() {
        return dataInvio + " - A: " + destinatario + " - Oggetto: " + oggetto;
    }
}