package Model;

import java.util.ArrayList;

/**
 * @brief Classe di utilità per la lettura delle email inviate.
 * * Questa classe gestisce la connessione al server IMAP di Gmail per recuperare
 * lo storico della posta inviata. Utilizza le API di JavaMail per connettersi,
 * navigare nelle cartelle e scaricare i metadati dei messaggi.
 * * @author GRUPPO22
 * @version 1.0
 */
public class EmailReader {

    /** * @name Credenziali Gmail
     * Dati di accesso per l'account di sistema.
     */
    ///@{
    private static final String username = "progettoGruppo22@gmail.com"; ///< Indirizzo email dell'account.
    
    private static final String password = "fkmc eprk dmsf wwox"; ///< Password applicativa per l'accesso IMAP.
    ///@}

    /** * @name Operazioni IMAP
     * Metodi per l'interazione con il server di posta.
     */
    ///@{

    /**
     * @brief Recupera la lista delle ultime email inviate.
     * * Il metodo esegue le seguenti operazioni:
     * 1. Configura le proprietà per la connessione IMAPS (SSL) su porta 993.
     * 2. Si connette allo Store di Gmail usando le credenziali statiche.
     * 3. Tenta di aprire la cartella "[Gmail]/Sent Mail". Se non esiste, prova "[Gmail]/Posta inviata".
     * 4. Calcola il range degli ultimi 40 messaggi per evitare caricamenti eccessivi.
     * 5. Itera sui messaggi in ordine inverso (dal più recente) estraendo Oggetto, Destinatario e Data.
     * 6. Chiude la connessione e restituisce la lista.
     * * @return ArrayList di oggetti EmailInfo contenente i dettagli dei messaggi inviati.
     */
    public static ArrayList<EmailInfo> leggiPostaInviata() {
        return null;
    }
    ///@}
}