package Model;

import Model.DataClass.Stato;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * @brief Classe modello che rappresenta un Prestito.
 * * Questa classe memorizza i dettagli di un'operazione di prestito, collegando
 * un libro (tramite ISBN) a un utente (tramite Matricola).
 * Gestisce le date di inizio, scadenza e restituzione, oltre allo stato corrente del prestito.
 * * @author GRUPPO22
 * @version 1.0
 */
public class Prestito {
    
    /** * @name Dati Identificativi
     * Riferimenti univoci al Libro e all'Utente.
     */
    ///@{
    private String isbn;        ///< Codice ISBN del libro prestato.
    private String matricola;   ///< Matricola dell'utente che ha richiesto il prestito.
    ///@}

    /** * @name Gestione Date
     * Informazioni temporali sulla durata del prestito.
     */
    ///@{
    private LocalDate inizio_prestito;  ///< Data in cui è stato registrato il prestito.
    private LocalDate restituzione;     ///< Data effettiva di restituzione (null se ancora in corso).
    private LocalDate data_scadenza;    ///< Data entro la quale il libro deve essere restituito.
    ///@}

    /** @brief Stato corrente del prestito (ATTIVO, IN_RITARDO, RESTITUITO, PROROGATO). */
    private Stato stato;

    /**
     * @brief Costruttore della classe Prestito.
     * Inizializza un nuovo oggetto prestito con tutti i dati necessari.
     * @param isbn Il codice ISBN del libro.
     * @param matricola La matricola dell'utente.
     * @param inizio_prestito La data di inizio.
     * @param restituzione La data di restituzione (può essere null alla creazione).
     * @param stato Lo stato iniziale.
     * @param data_scadenza La data di scadenza calcolata.
     */
    public Prestito(String isbn, String matricola, LocalDate inizio_prestito, LocalDate restituzione, Stato stato, LocalDate data_scadenza) {

    }

    /**
     * @brief Metodo di utilità per filtrare una lista di prestiti in base allo stato.
     * * Scorre una lista di prestiti e restituisce una nuova lista contenente solo
     * quelli che corrispondono allo stato passato come parametro.
     * * @param p L'ArrayList di prestiti da filtrare.
     * @param s Lo stato desiderato (es. Stato.IN_RITARDO).
     * @return Un nuovo ArrayList contenente solo i prestiti filtrati.
     */
    public static ArrayList<Prestito> getPrestitiByStato(ArrayList<Prestito> p, Stato s){
        return null;
    }
    
    // --- GETTERS & SETTERS ---

    /**
     * @brief Restituisce la data di scadenza del prestito.
     * @return Oggetto LocalDate.
     */
    public LocalDate getData_scadenza() {
        return data_scadenza;
    }

    /**
     * @brief Imposta la data di scadenza (es. in caso di proroga).
     * @param data_scadenza Nuova data di scadenza.
     */
    public void setData_scadenza(LocalDate data_scadenza) {

    }

    /**
     * @brief Restituisce l'ISBN del libro.
     * @return Stringa ISBN.
     */
    public String getIsbn() {
        return isbn;
    }

    /**
     * @brief Imposta l'ISBN del libro.
     * @param isbn Nuovo ISBN.
     */
    public void setIsbn(String isbn) {

    }

    /**
     * @brief Restituisce la matricola dell'utente.
     * @return Stringa Matricola.
     */
    public String getMatricola() {
        return matricola;
    }

    /**
     * @brief Imposta la matricola dell'utente.
     * @param matricola Nuova matricola.
     */
    public void setMatricola(String matricola) {

    }

    /**
     * @brief Restituisce la data di inizio prestito.
     * @return Oggetto LocalDate.
     */
    public LocalDate getInizio_prestito() {
        return inizio_prestito;
    }

    /**
     * @brief Imposta la data di inizio prestito.
     * @param inizio_prestito Nuova data di inizio.
     */
    public void setInizio_prestito(LocalDate inizio_prestito) {

    }

    /**
     * @brief Restituisce la data di restituzione effettiva.
     * @return Oggetto LocalDate o null se non ancora restituito.
     */
    public LocalDate getRestituzione() {
        return restituzione;
    }

    /**
     * @brief Imposta la data di restituzione.
     * @param restituzione Data in cui il libro è stato reso.
     */
    public void setRestituzione(LocalDate restituzione) {

    }

    /**
     * @brief Restituisce lo stato attuale del prestito.
     * @return Enum Stato.
     */
    public Stato getStato() {
        return stato;
    }

    /**
     * @brief Aggiorna lo stato del prestito.
     * @param stato Nuovo stato.
     */
    public void setStato(Stato stato) {

    }

    /**
     * @brief Rappresentazione testuale dell'oggetto Prestito.
     * @return Stringa con tutti i dati del prestito.
     */
    @Override
    public String toString() {
        return null;
    }
}