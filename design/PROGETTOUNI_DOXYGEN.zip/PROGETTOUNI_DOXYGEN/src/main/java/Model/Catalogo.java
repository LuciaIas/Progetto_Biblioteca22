package Model;

import Model.DataClass.Libro;
import java.util.ArrayList;
import java.util.List;


/**
 * @brief Classe che rappresenta il Catalogo dei libri.
 * * Questa classe funge da lista di oggetti `Libro`.
 * Fornisce metodi per aggiungere, rimuovere, ordinare e ricercare libri
 * all'interno della collezione (per ISBN, Titolo o Autore).
 * * @author GRUPPO22
 * @version 1.0
 */
public class Catalogo {

    /** @brief Lista interna contenente tutti i libri del catalogo. */
    private List<Libro> libri;

    /**
     * @brief Costruttore della classe Catalogo.
     * Inizializza la lista interna come un nuovo ArrayList vuoto.
     */
    public Catalogo() {

    }

    /**
     * @brief Aggiunge un libro al catalogo.
     * @param libro L'oggetto `Libro` da aggiungere alla lista.
     */
    public void aggiungiLibro(Libro libro) {

    }

    /**
     * @brief Rimuove un libro dal catalogo.
     * @param libro L'oggetto `Libro` da rimuovere dalla lista.
     */
    public void rimuoviLibro(Libro libro) {

    }

    /**
     * @brief Restituisce l'intera lista dei libri.
     * @return Un ArrayList<Libro> contenente tutti i libri presenti.
     */
    public ArrayList<Libro> getLibri() {
        return (ArrayList<Libro>) libri;
    }

    /**
     * @brief Ordina il catalogo in ordine alfabetico.
     * Utilizza un Comparator per ordinare la lista in base al titolo del libro,
     * ignorando le differenze tra maiuscole e minuscole (toUpperCase).
     */
    public void sort(){

    }
    
    /**
     * @brief Cerca un libro specifico tramite codice ISBN.
     * Esegue una ricerca lineare nella lista.
     * @param isbn La stringa ISBN da cercare.
     * @return L'oggetto `Libro` corrispondente se trovato, altrimenti null.
     */
    public Libro cercaPerIsbn(String isbn) {
        return null;//se lo trovo torna il libro
    }

    /**
     * @brief Cerca libri tramite il titolo.
     * Utilizza gli Stream di Java per filtrare la lista.
     * La ricerca è case-insensitive e parziale (controlla se il titolo contiene la stringa cercata).
     * @param titolo Il titolo (o parte di esso) da cercare.
     * @return Una `List<Libro>` contenente tutti i libri che soddisfano i criteri.
     */
    public List<Libro> cercaPerTitolo(String titolo) {
        return null;//ritorna una list contenente tutti i libri che soddisfano i criteri
    }

    /**
     * @brief Cerca libri scritti da un determinato autore.
     * Utilizza gli Stream di Java per filtrare la lista controllando se l'autore è presente nella lista autori del libro.
     * @param autore Il nome/cognome dell'autore da cercare.
     * @return Una `List<Libro>` contenente i libri scritti dall'autore specificato.
     */
    public List<Libro> cercaPerAutore(String autore) {
        return null;//lista dei libri contenente i libri scritti dall'autore specificato
    }
}