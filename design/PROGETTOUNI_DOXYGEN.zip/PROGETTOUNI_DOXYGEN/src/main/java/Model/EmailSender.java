package Model;

import java.time.LocalDate;


/**
 * @brief Classe di utilità per l'invio di email tramite server SMTP.
 * * Questa classe gestisce l'autenticazione e l'invio di messaggi di posta elettronica
 * utilizzando le JavaMail e il server SMTP di Gmail.
 * Fornisce metodi sia per l'invio di messaggi generici che per notifiche specifiche
 * di mancata restituzione (avvisi).
 * * @author GRUPPO22
 * @version 1.0
 */
public class EmailSender {

    /** * @name Credenziali Account Sistema
     * Dati per l'autenticazione SMTP.
     */
    ///@{
    private static final String username = "progettoGruppo22@gmail.com"; ///< Indirizzo email del mittente.
    
    private static final String password = "fzxw ejrj caqq huez"; ///< Password applicativa per l'accesso SMTP.
    ///@}

    /**
     * @brief Invia un'email generica in modo sincrono.
     * * Configura le proprietà della sessione (host: smtp.gmail.com, porta: 587, TLS attivo),
     * esegue l'autenticazione e spedisce il messaggio.
     * Gestisce internamente le eccezioni di tipo MessagingException.
     * * @param recipientEmail Indirizzo email del destinatario.
     * @param subject Oggetto dell'email.
     * @param body Corpo del messaggio.
     */
    public static void sendEmail(String recipientEmail, String subject, String body) {

    }


    /**
     * @brief Invia un avviso di mancata restituzione (Sollecito).
     * * Questo metodo prepara un messaggio preformattato indirizzato all'utente specificato
     * e lo invia utilizzando un **Thread separato** per non bloccare l'esecuzione dell'interfaccia utente.
     * Il messaggio varia leggermente se viene specificato un titolo del libro o se è un sollecito generico.
     * * @param recipientEmail Email dell'utente.
     * @param titolo Titolo del libro (se null, invia messaggio generico).
     * @param nome Nome dell'utente.
     * @param cognome Cognome dell'utente.
     * @param inizioPrestito Data in cui è iniziato il prestito.
     * @return true se il thread è stato avviato correttamente.
     */
    public static boolean SendAvviso(String recipientEmail,String titolo,String nome,String cognome,LocalDate inizioPrestito){
        return true;//esito operazione
    }
    
}