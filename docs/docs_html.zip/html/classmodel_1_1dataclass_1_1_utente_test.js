var classmodel_1_1dataclass_1_1_utente_test =
[
    [ "testAggiornamentoProfilo", "classmodel_1_1dataclass_1_1_utente_test.html#acdc71c28ed74c11bd1e3d4a930669ae6", null ],
    [ "testBlacklistVuota", "classmodel_1_1dataclass_1_1_utente_test.html#ae27a520ce2b826609bf59d3d8d5fe5f8", null ],
    [ "testCostruttoreEGetters", "classmodel_1_1dataclass_1_1_utente_test.html#a41b464900fd84991b4dce45e3c30cff8", null ],
    [ "testFiltroBlacklist", "classmodel_1_1dataclass_1_1_utente_test.html#a104e5350692cb606da1ad27240c30052", null ],
    [ "testModificaStatoBlocco", "classmodel_1_1dataclass_1_1_utente_test.html#a4174b404924f2c34e07022e076a95f66", null ]
];