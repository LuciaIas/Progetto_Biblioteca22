var dir_d2ec8ea58377dc85152a985771c6e6da =
[
    [ "dataclass", "dir_cfa945dee10c26df070afd264d1a0415.html", "dir_cfa945dee10c26df070afd264d1a0415" ],
    [ "servizi", "dir_76fa8cfbad69a738310ca87f1c93c68d.html", "dir_76fa8cfbad69a738310ca87f1c93c68d" ],
    [ "ConfigurazioneTest.java", "_configurazione_test_8java.html", "_configurazione_test_8java" ],
    [ "TransizioneScenaTest.java", "_transizione_scena_test_8java.html", "_transizione_scena_test_8java" ]
];