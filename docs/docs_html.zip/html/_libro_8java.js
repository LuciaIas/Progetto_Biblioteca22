var _libro_8java =
[
    [ "model.dataclass.Libro", "classmodel_1_1dataclass_1_1_libro.html", "classmodel_1_1dataclass_1_1_libro" ]
];