var classcontroller_1_1_dashboard_controller =
[
    [ "buttonInitialize", "classcontroller_1_1_dashboard_controller.html#a10372cda734073c8931068163012fd6f", null ],
    [ "initialize", "classcontroller_1_1_dashboard_controller.html#a0751c869c124270f187b2636a3858d74", null ],
    [ "labelInitialize", "classcontroller_1_1_dashboard_controller.html#a906b2571885cea0fadd5fa2f85b7c373", null ]
];