var dir_db9b49385c2f2a6a62f75ae1753957ce =
[
    [ "dataclass", "dir_65d73c6fdf9fb8579b362dcf24d8615e.html", "dir_65d73c6fdf9fb8579b362dcf24d8615e" ],
    [ "servizi", "dir_2bfd9206f5077966f8fb51494112460c.html", "dir_2bfd9206f5077966f8fb51494112460c" ],
    [ "Configurazione.java", "_configurazione_8java.html", "_configurazione_8java" ],
    [ "TransizioneScena.java", "_transizione_scena_8java.html", "_transizione_scena_8java" ]
];