var namespacemodel_1_1dataclass =
[
    [ "Autore", "classmodel_1_1dataclass_1_1_autore.html", "classmodel_1_1dataclass_1_1_autore" ],
    [ "AutoreTest", "classmodel_1_1dataclass_1_1_autore_test.html", "classmodel_1_1dataclass_1_1_autore_test" ],
    [ "EmailInfo", "classmodel_1_1dataclass_1_1_email_info.html", "classmodel_1_1dataclass_1_1_email_info" ],
    [ "EmailInfoTest", "classmodel_1_1dataclass_1_1_email_info_test.html", "classmodel_1_1dataclass_1_1_email_info_test" ],
    [ "Libro", "classmodel_1_1dataclass_1_1_libro.html", "classmodel_1_1dataclass_1_1_libro" ],
    [ "LibroTest", "classmodel_1_1dataclass_1_1_libro_test.html", "classmodel_1_1dataclass_1_1_libro_test" ],
    [ "Stato", "enummodel_1_1dataclass_1_1_stato.html", "enummodel_1_1dataclass_1_1_stato" ],
    [ "Utente", "classmodel_1_1dataclass_1_1_utente.html", "classmodel_1_1dataclass_1_1_utente" ],
    [ "UtenteTest", "classmodel_1_1dataclass_1_1_utente_test.html", "classmodel_1_1dataclass_1_1_utente_test" ]
];