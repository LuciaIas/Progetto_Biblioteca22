var _blacklist_controller_test_8java =
[
    [ "controller.BlacklistControllerTest", "classcontroller_1_1_blacklist_controller_test.html", "classcontroller_1_1_blacklist_controller_test" ]
];