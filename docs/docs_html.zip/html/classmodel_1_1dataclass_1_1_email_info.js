var classmodel_1_1dataclass_1_1_email_info =
[
    [ "EmailInfo", "classmodel_1_1dataclass_1_1_email_info.html#aabaa53b7c5aa18b774907471da5e268a", null ],
    [ "getDataInvio", "classmodel_1_1dataclass_1_1_email_info.html#af669bc4e2a522c8afeceddea27c7ce6a", null ],
    [ "getDestinatario", "classmodel_1_1dataclass_1_1_email_info.html#a5ea5ceeec5f5c769c6c546bea9b026fc", null ],
    [ "getOggetto", "classmodel_1_1dataclass_1_1_email_info.html#a9ed859151e19cbaf0457f9c33cc850cd", null ],
    [ "toString", "classmodel_1_1dataclass_1_1_email_info.html#a5255ed6d6cc4aa80e278baa3c4a8f529", null ]
];