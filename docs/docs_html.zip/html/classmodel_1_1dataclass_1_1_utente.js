var classmodel_1_1dataclass_1_1_utente =
[
    [ "Utente", "classmodel_1_1dataclass_1_1_utente.html#aab1b56bb2bcf86812284b1c893bafd60", null ],
    [ "getCognome", "classmodel_1_1dataclass_1_1_utente.html#a171f14e002c8da71fba25fba1ab15303", null ],
    [ "getMail", "classmodel_1_1dataclass_1_1_utente.html#ab2bed7288213104ae013d62831de7867", null ],
    [ "getMatricola", "classmodel_1_1dataclass_1_1_utente.html#a20baed05f68e2bcbc275adc0ebd6408b", null ],
    [ "getNome", "classmodel_1_1dataclass_1_1_utente.html#ac40f3d94ee69123d8c07b9dfb5126e57", null ],
    [ "isBloccato", "classmodel_1_1dataclass_1_1_utente.html#aa701dc86470200ab36a816f56026f4c9", null ],
    [ "setBloccato", "classmodel_1_1dataclass_1_1_utente.html#ac5f8ae48e5db6d44b1b50b7d0cae3aad", null ],
    [ "setCognome", "classmodel_1_1dataclass_1_1_utente.html#a0e884902a530ec9efa9bd2d88d0ada70", null ],
    [ "setMail", "classmodel_1_1dataclass_1_1_utente.html#a77610bae89aaaf22dfb446a7cbccd311", null ],
    [ "setMatricola", "classmodel_1_1dataclass_1_1_utente.html#ac91effe98865a943c59f934467ab1f12", null ],
    [ "setNome", "classmodel_1_1dataclass_1_1_utente.html#ad12f3d6794f5bfb573d865ecadc0b4a8", null ],
    [ "toString", "classmodel_1_1dataclass_1_1_utente.html#a9b0a3041f6209287cb6c019071cb3823", null ]
];