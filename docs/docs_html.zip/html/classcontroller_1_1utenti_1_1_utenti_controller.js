var classcontroller_1_1utenti_1_1_utenti_controller =
[
    [ "buttonInitialize", "classcontroller_1_1utenti_1_1_utenti_controller.html#aba7d92179939bbda95d41b6290a3f205", null ],
    [ "initialize", "classcontroller_1_1utenti_1_1_utenti_controller.html#a4040b3d81303e5321e74e977b976295f", null ],
    [ "labelInitialize", "classcontroller_1_1utenti_1_1_utenti_controller.html#ac4de610e06f7067488c7eb4531c3cdb9", null ],
    [ "menuButtonInitialize", "classcontroller_1_1utenti_1_1_utenti_controller.html#a73f41e8b44114d9b61a8edffeb29075e", null ],
    [ "searchFunction", "classcontroller_1_1utenti_1_1_utenti_controller.html#ae1cc52c1f67e8faef33bfde08f3979a6", null ],
    [ "updateUtentiList", "classcontroller_1_1utenti_1_1_utenti_controller.html#a2b77d33ef90fa5b910e130e63f232511", null ]
];