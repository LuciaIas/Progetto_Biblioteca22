var _prestito_8java =
[
    [ "model.servizi.Prestito", "classmodel_1_1servizi_1_1_prestito.html", "classmodel_1_1servizi_1_1_prestito" ]
];