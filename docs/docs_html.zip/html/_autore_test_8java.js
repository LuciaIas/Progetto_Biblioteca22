var _autore_test_8java =
[
    [ "model.dataclass.AutoreTest", "classmodel_1_1dataclass_1_1_autore_test.html", "classmodel_1_1dataclass_1_1_autore_test" ]
];