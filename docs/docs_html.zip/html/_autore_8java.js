var _autore_8java =
[
    [ "model.dataclass.Autore", "classmodel_1_1dataclass_1_1_autore.html", "classmodel_1_1dataclass_1_1_autore" ]
];