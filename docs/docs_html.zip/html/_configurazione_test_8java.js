var _configurazione_test_8java =
[
    [ "model.ConfigurazioneTest", "classmodel_1_1_configurazione_test.html", "classmodel_1_1_configurazione_test" ]
];