var _data_base_test_8java =
[
    [ "model.servizi.DataBaseTest", "classmodel_1_1servizi_1_1_data_base_test.html", "classmodel_1_1servizi_1_1_data_base_test" ]
];