var _transizione_scena_8java =
[
    [ "model.TransizioneScena", "classmodel_1_1_transizione_scena.html", null ]
];