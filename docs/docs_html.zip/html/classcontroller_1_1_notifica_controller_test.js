var classcontroller_1_1_notifica_controller_test =
[
    [ "start", "classcontroller_1_1_notifica_controller_test.html#a2105324dd2dd077ca2edfe252370ccbf", null ],
    [ "tearDown", "classcontroller_1_1_notifica_controller_test.html#ac3440f037c050f83819c30f64dcf5dd9", null ],
    [ "testMessaggioNotifica", "classcontroller_1_1_notifica_controller_test.html#a91e92cf7582ce972fb32e692c4bc691b", null ]
];