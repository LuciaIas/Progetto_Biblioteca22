var classmodel_1_1servizi_1_1_catalogo =
[
    [ "Catalogo", "classmodel_1_1servizi_1_1_catalogo.html#a221f09dac3d68009b33458af48bef4e9", null ],
    [ "aggiungiLibro", "classmodel_1_1servizi_1_1_catalogo.html#a80c8ae7627e0f7aa800fef5bf6793a2e", null ],
    [ "cercaPerAutore", "classmodel_1_1servizi_1_1_catalogo.html#ab7014e66e7f3642726767faf5c50add4", null ],
    [ "cercaPerIsbn", "classmodel_1_1servizi_1_1_catalogo.html#a2075636070b2e7212969501874eda25b", null ],
    [ "cercaPerTitolo", "classmodel_1_1servizi_1_1_catalogo.html#ac159dc4f8c7385ee601719108b39d347", null ],
    [ "getLibri", "classmodel_1_1servizi_1_1_catalogo.html#a5579a89578055e70ed095b0259e4d75d", null ],
    [ "rimuoviLibro", "classmodel_1_1servizi_1_1_catalogo.html#ae8546edd3ef102c75260c8e6a9519985", null ],
    [ "sort", "classmodel_1_1servizi_1_1_catalogo.html#aeaaa3f22571afdf688af81a218925f24", null ]
];