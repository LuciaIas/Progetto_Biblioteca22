var dir_3628de3e30dd26cf651ec10080b4016a =
[
    [ "AggiungiLibroController.java", "_aggiungi_libro_controller_8java.html", "_aggiungi_libro_controller_8java" ],
    [ "CatalogoController.java", "_catalogo_controller_8java.html", "_catalogo_controller_8java" ],
    [ "ModificaLibroController.java", "_modifica_libro_controller_8java.html", "_modifica_libro_controller_8java" ]
];