var _operazioni_giornaliere_8java =
[
    [ "model.servizi.OperazioniGiornaliere", "classmodel_1_1servizi_1_1_operazioni_giornaliere.html", null ]
];