var _modifica_libro_controller_8java =
[
    [ "controller.catalogo.ModificaLibroController", "classcontroller_1_1catalogo_1_1_modifica_libro_controller.html", "classcontroller_1_1catalogo_1_1_modifica_libro_controller" ]
];