var classmodel_1_1dataclass_1_1_autore_test =
[
    [ "testCostruttoreEGetter", "classmodel_1_1dataclass_1_1_autore_test.html#afc4832d9cabc7a0c18f26067d6ffdfb5", null ],
    [ "testSetters", "classmodel_1_1dataclass_1_1_autore_test.html#aa4db382152c4872c674dc21f6752fca0", null ],
    [ "testToString", "classmodel_1_1dataclass_1_1_autore_test.html#ad6013741526c56eeeb20942fda46771f", null ],
    [ "testValoriNull", "classmodel_1_1dataclass_1_1_autore_test.html#af73ab6effe2924e463305bc5767763ed", null ]
];