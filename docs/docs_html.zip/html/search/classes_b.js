var searchData=
[
  ['stato_0',['Stato',['../enummodel_1_1dataclass_1_1_stato.html',1,'model::dataclass']]]
];
