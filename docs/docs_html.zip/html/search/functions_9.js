var searchData=
[
  ['restituisci_0',['restituisci',['../classmodel_1_1servizi_1_1_data_base.html#a1b8aa7c3a5a5576f91d6d619bf4456ff',1,'model::servizi::DataBase']]],
  ['rimuovibibliotecario_1',['rimuoviBibliotecario',['../classmodel_1_1servizi_1_1_data_base.html#acbdb62a655fc2c9563b165f5bcc0ec86',1,'model::servizi::DataBase']]],
  ['rimuovilibro_2',['rimuoviLibro',['../classmodel_1_1servizi_1_1_catalogo.html#ae8546edd3ef102c75260c8e6a9519985',1,'model.servizi.Catalogo.rimuoviLibro()'],['../classmodel_1_1servizi_1_1_data_base.html#a3af97e98ae15e664a1ce96c647639379',1,'model.servizi.DataBase.rimuoviLibro(String isbn)']]],
  ['rimuoviprestito_3',['rimuoviPrestito',['../classmodel_1_1servizi_1_1_data_base.html#aa0596d280241e369fb9b5f27598ccf6d',1,'model::servizi::DataBase']]],
  ['rimuoviutente_4',['rimuoviUtente',['../classmodel_1_1servizi_1_1_data_base.html#ad01075d7dc886ec82f20c647dddce018',1,'model::servizi::DataBase']]]
];
