var searchData=
[
  ['in_5fritardo_0',['IN_RITARDO',['../enummodel_1_1dataclass_1_1_stato.html#a802258455705bb9910d5ffd1ff5ae289',1,'model::dataclass::Stato']]],
  ['isbn_1',['isbn',['../classcontroller_1_1catalogo_1_1_modifica_libro_controller.html#a6fabd76b211348ebb3d907d1577eb90b',1,'controller::catalogo::ModificaLibroController']]]
];
