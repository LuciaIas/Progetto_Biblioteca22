var searchData=
[
  ['restituito_0',['RESTITUITO',['../enummodel_1_1dataclass_1_1_stato.html#a3b412c1b3aaf745f7ec9a3253273e4b9',1,'model::dataclass::Stato']]]
];
