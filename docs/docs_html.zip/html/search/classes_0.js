var searchData=
[
  ['accessocontroller_0',['AccessoController',['../classcontroller_1_1_accesso_controller.html',1,'controller']]],
  ['accessocontrollertest_1',['AccessoControllerTest',['../classcontroller_1_1_accesso_controller_test.html',1,'controller']]],
  ['aggiungilibrocontroller_2',['AggiungiLibroController',['../classcontroller_1_1catalogo_1_1_aggiungi_libro_controller.html',1,'controller::catalogo']]],
  ['aggiungiprestitocontroller_3',['AggiungiPrestitoController',['../classcontroller_1_1prestitorestituzione_1_1_aggiungi_prestito_controller.html',1,'controller::prestitorestituzione']]],
  ['aggiungiutentecontroller_4',['AggiungiUtenteController',['../classcontroller_1_1utenti_1_1_aggiungi_utente_controller.html',1,'controller::utenti']]],
  ['autore_5',['Autore',['../classmodel_1_1dataclass_1_1_autore.html',1,'model::dataclass']]],
  ['autoretest_6',['AutoreTest',['../classmodel_1_1dataclass_1_1_autore_test.html',1,'model::dataclass']]]
];
