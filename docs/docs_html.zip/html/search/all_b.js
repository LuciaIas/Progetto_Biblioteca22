var searchData=
[
  ['passrec_0',['PassRec',['../classcontroller_1_1_dashboard_controller.html#ab4a5ff22a426919e109118f2489bfccc',1,'controller::DashboardController']]],
  ['preliminaryfunctions_1',['PreliminaryFunctions',['../classmain_1_1_main.html#aad67ca43f06a02ca0ebefd9ae3df031d',1,'main::Main']]],
  ['prestito_2',['Prestito',['../classmodel_1_1servizi_1_1_prestito.html',1,'model.servizi.Prestito'],['../classmodel_1_1servizi_1_1_prestito.html#a5c07c4b76a5dec594172e79432801dee',1,'model.servizi.Prestito.Prestito()']]],
  ['prestito_2ejava_3',['Prestito.java',['../_prestito_8java.html',1,'']]],
  ['prestitorestituzionecontroller_4',['PrestitoRestituzioneController',['../classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller.html',1,'controller::prestitorestituzione']]],
  ['prestitorestituzionecontroller_2ejava_5',['PrestitoRestituzioneController.java',['../_prestito_restituzione_controller_8java.html',1,'']]],
  ['prestitotest_6',['PrestitoTest',['../classmodel_1_1servizi_1_1_prestito_test.html',1,'model::servizi']]],
  ['prestitotest_2ejava_7',['PrestitoTest.java',['../_prestito_test_8java.html',1,'']]],
  ['prorogaprestito_8',['prorogaPrestito',['../classmodel_1_1servizi_1_1_data_base.html#a4c9c6b2f6218b09a76dbf019ac005797',1,'model::servizi::DataBase']]],
  ['prorogato_9',['PROROGATO',['../enummodel_1_1dataclass_1_1_stato.html#a59c921aec5783f46f7f380a2ad54025e',1,'model::dataclass::Stato']]],
  ['pulisciconfigurazione_10',['pulisciConfigurazione',['../classmodel_1_1_configurazione_test.html#a6ef9377e80c19d8456a30e54e3ba7ed6',1,'model::ConfigurazioneTest']]]
];
