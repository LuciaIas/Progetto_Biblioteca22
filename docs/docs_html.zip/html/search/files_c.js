var searchData=
[
  ['transizionescena_2ejava_0',['TransizioneScena.java',['../_transizione_scena_8java.html',1,'']]],
  ['transizionescenatest_2ejava_1',['TransizioneScenaTest.java',['../_transizione_scena_test_8java.html',1,'']]]
];
