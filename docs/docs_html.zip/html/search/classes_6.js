var searchData=
[
  ['libro_0',['Libro',['../classmodel_1_1dataclass_1_1_libro.html',1,'model::dataclass']]],
  ['librotest_1',['LibroTest',['../classmodel_1_1dataclass_1_1_libro_test.html',1,'model::dataclass']]]
];
