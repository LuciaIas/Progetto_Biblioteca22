var searchData=
[
  ['prestito_0',['Prestito',['../classmodel_1_1servizi_1_1_prestito.html',1,'model::servizi']]],
  ['prestitorestituzionecontroller_1',['PrestitoRestituzioneController',['../classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller.html',1,'controller::prestitorestituzione']]],
  ['prestitotest_2',['PrestitoTest',['../classmodel_1_1servizi_1_1_prestito_test.html',1,'model::servizi']]]
];
