var searchData=
[
  ['emailinfo_0',['EmailInfo',['../classmodel_1_1dataclass_1_1_email_info.html#aabaa53b7c5aa18b774907471da5e268a',1,'model::dataclass::EmailInfo']]],
  ['eseguibackup_1',['eseguiBackup',['../classmodel_1_1servizi_1_1_backup.html#a54b6ec8c9844f8ee3f484f38395e2bba',1,'model::servizi::Backup']]],
  ['eseguicontrolliautomatici_2',['eseguiControlliAutomatici',['../classmodel_1_1servizi_1_1_operazioni_giornaliere.html#a1bd8bd889312c1725f197f4c8b53fbc5',1,'model::servizi::OperazioniGiornaliere']]]
];
