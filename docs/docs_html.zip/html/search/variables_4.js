var searchData=
[
  ['open_5ftime_0',['open_time',['../classmain_1_1_main.html#a8697a39831c0d526da3b7e6dcc5caf88',1,'main::Main']]]
];
