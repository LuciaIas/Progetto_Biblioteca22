var searchData=
[
  ['matricola_0',['matricola',['../classcontroller_1_1utenti_1_1_modifica_utente_controller.html#a62364c8611d5127219995632395c9bc4',1,'controller::utenti::ModificaUtenteController']]],
  ['max_5fautors_1',['MAX_AUTORS',['../classcontroller_1_1catalogo_1_1_aggiungi_libro_controller.html#abe362e241f25653b7bdb933c7b980979',1,'controller::catalogo::AggiungiLibroController']]],
  ['max_5fbooks_2',['MAX_BOOKS',['../classcontroller_1_1catalogo_1_1_catalogo_controller.html#a9b0fd88a45c600c51a8fcfa9408da085',1,'controller::catalogo::CatalogoController']]],
  ['max_5floan_3',['MAX_LOAN',['../classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller.html#ab6ba34b0b58818a67ef9dd517e8015f7',1,'controller::prestitorestituzione::PrestitoRestituzioneController']]],
  ['max_5fusers_4',['MAX_USERS',['../classcontroller_1_1utenti_1_1_utenti_controller.html#ae6e9fe281e2ab464acc2727b87cc08f0',1,'controller::utenti::UtentiController']]],
  ['max_5fwrited_5',['MAX_WRITED',['../classcontroller_1_1catalogo_1_1_aggiungi_libro_controller.html#a519c43caf6dc71e00a6cdaf0c57b8ba0',1,'controller::catalogo::AggiungiLibroController']]]
];
