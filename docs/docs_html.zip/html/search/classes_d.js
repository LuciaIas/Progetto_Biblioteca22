var searchData=
[
  ['utente_0',['Utente',['../classmodel_1_1dataclass_1_1_utente.html',1,'model::dataclass']]],
  ['utentetest_1',['UtenteTest',['../classmodel_1_1dataclass_1_1_utente_test.html',1,'model::dataclass']]],
  ['utenticontroller_2',['UtentiController',['../classcontroller_1_1utenti_1_1_utenti_controller.html',1,'controller::utenti']]]
];
