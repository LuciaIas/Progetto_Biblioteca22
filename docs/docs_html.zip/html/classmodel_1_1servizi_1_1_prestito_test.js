var classmodel_1_1servizi_1_1_prestito_test =
[
    [ "testCostruttoreEGetter", "classmodel_1_1servizi_1_1_prestito_test.html#ad0cd0d76061c5616a909937bfc68018b", null ],
    [ "testFiltroPrestiti_ListaVuota", "classmodel_1_1servizi_1_1_prestito_test.html#a8d3c89ffbe010b585f994f86fc5fbe33", null ],
    [ "testFiltroPrestiti_NessunRisultato", "classmodel_1_1servizi_1_1_prestito_test.html#a50b43d6ada1b06ef75e18c2c903b1b13", null ],
    [ "testFiltroPrestitiByStato", "classmodel_1_1servizi_1_1_prestito_test.html#a09d7578501f421ad49eba96f3e69ae24", null ],
    [ "testModificaStato", "classmodel_1_1servizi_1_1_prestito_test.html#a9e2271b3aadb85b74c4f776fe1d951b1", null ]
];