var _libro_test_8java =
[
    [ "model.dataclass.LibroTest", "classmodel_1_1dataclass_1_1_libro_test.html", "classmodel_1_1dataclass_1_1_libro_test" ]
];