var _prestito_test_8java =
[
    [ "model.servizi.PrestitoTest", "classmodel_1_1servizi_1_1_prestito_test.html", "classmodel_1_1servizi_1_1_prestito_test" ]
];