var enummodel_1_1dataclass_1_1_stato =
[
    [ "ATTIVO", "enummodel_1_1dataclass_1_1_stato.html#a95012a0a30ce68f9dc302f0e17146ab9", null ],
    [ "IN_RITARDO", "enummodel_1_1dataclass_1_1_stato.html#a802258455705bb9910d5ffd1ff5ae289", null ],
    [ "PROROGATO", "enummodel_1_1dataclass_1_1_stato.html#a59c921aec5783f46f7f380a2ad54025e", null ],
    [ "RESTITUITO", "enummodel_1_1dataclass_1_1_stato.html#a3b412c1b3aaf745f7ec9a3253273e4b9", null ]
];