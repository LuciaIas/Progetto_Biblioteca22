var _catalogo_8java =
[
    [ "model.servizi.Catalogo", "classmodel_1_1servizi_1_1_catalogo.html", "classmodel_1_1servizi_1_1_catalogo" ]
];