var classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller =
[
    [ "buttonInitialize", "classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller.html#a04c47791e354436525f9ce1ecae84000", null ],
    [ "initialize", "classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller.html#acf8eba3ef5eadcd0b9dd054ce8a5e5a6", null ],
    [ "menuButtonInitialize", "classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller.html#aa0febd0527acbf00453ce8b45ec39d6c", null ],
    [ "searchFunction", "classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller.html#af78e93a1a469d540481d4076ab75aea7", null ],
    [ "updatePrestiti", "classcontroller_1_1prestitorestituzione_1_1_prestito_restituzione_controller.html#a955612a65c5ae24911a5e743eba90cd3", null ]
];