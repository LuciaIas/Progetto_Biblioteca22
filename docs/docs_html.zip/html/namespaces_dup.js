var namespaces_dup =
[
    [ "controller", "namespacecontroller.html", "namespacecontroller" ],
    [ "main", "namespacemain.html", "namespacemain" ],
    [ "model", "namespacemodel.html", "namespacemodel" ]
];