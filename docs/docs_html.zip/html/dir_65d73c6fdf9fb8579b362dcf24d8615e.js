var dir_65d73c6fdf9fb8579b362dcf24d8615e =
[
    [ "Autore.java", "_autore_8java.html", "_autore_8java" ],
    [ "EmailInfo.java", "_email_info_8java.html", "_email_info_8java" ],
    [ "Libro.java", "_libro_8java.html", "_libro_8java" ],
    [ "Stato.java", "_stato_8java.html", "_stato_8java" ],
    [ "Utente.java", "_utente_8java.html", "_utente_8java" ]
];