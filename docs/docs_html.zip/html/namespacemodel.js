var namespacemodel =
[
    [ "dataclass", "namespacemodel_1_1dataclass.html", "namespacemodel_1_1dataclass" ],
    [ "servizi", "namespacemodel_1_1servizi.html", "namespacemodel_1_1servizi" ],
    [ "Configurazione", "classmodel_1_1_configurazione.html", null ],
    [ "ConfigurazioneTest", "classmodel_1_1_configurazione_test.html", "classmodel_1_1_configurazione_test" ],
    [ "TransizioneScena", "classmodel_1_1_transizione_scena.html", null ],
    [ "TransizioneScenaTest", "classmodel_1_1_transizione_scena_test.html", "classmodel_1_1_transizione_scena_test" ]
];