var _notifica_controller_8java =
[
    [ "controller.NotificaController", "classcontroller_1_1_notifica_controller.html", "classcontroller_1_1_notifica_controller" ]
];