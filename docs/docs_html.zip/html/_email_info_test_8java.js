var _email_info_test_8java =
[
    [ "model.dataclass.EmailInfoTest", "classmodel_1_1dataclass_1_1_email_info_test.html", "classmodel_1_1dataclass_1_1_email_info_test" ]
];