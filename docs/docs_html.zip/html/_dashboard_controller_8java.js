var _dashboard_controller_8java =
[
    [ "controller.DashboardController", "classcontroller_1_1_dashboard_controller.html", "classcontroller_1_1_dashboard_controller" ]
];