var _email_info_8java =
[
    [ "model.dataclass.EmailInfo", "classmodel_1_1dataclass_1_1_email_info.html", "classmodel_1_1dataclass_1_1_email_info" ]
];