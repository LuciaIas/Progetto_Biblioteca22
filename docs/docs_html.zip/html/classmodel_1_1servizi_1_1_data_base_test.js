var classmodel_1_1servizi_1_1_data_base_test =
[
    [ "setUp", "classmodel_1_1servizi_1_1_data_base_test.html#a87131121bd3eaf1622422b0db768f0ca", null ],
    [ "tearDown", "classmodel_1_1servizi_1_1_data_base_test.html#a2c0f0a4e485a5c444b95ae95d9dbda63", null ],
    [ "testBlacklistUtente", "classmodel_1_1servizi_1_1_data_base_test.html#a64721217888bc69cb3ec0614cad9c0e3", null ],
    [ "testFlussoInserimentoLibro", "classmodel_1_1servizi_1_1_data_base_test.html#a2a74926f0da6025efdf7946d2a5617bf", null ],
    [ "testGestioneUtenti", "classmodel_1_1servizi_1_1_data_base_test.html#a2751e8a33dc605ee0a7fde853547da88", null ],
    [ "testInserimentoEControlloPassword", "classmodel_1_1servizi_1_1_data_base_test.html#aca47743d7bb82460906ef729facaac7b", null ],
    [ "testModificaNumCopie", "classmodel_1_1servizi_1_1_data_base_test.html#abdc218303b3d29bb9c1a5d51782662d0", null ]
];