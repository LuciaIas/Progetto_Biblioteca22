var _email_legge_8java =
[
    [ "model.servizi.EmailLegge", "classmodel_1_1servizi_1_1_email_legge.html", null ]
];