var _blacklist_controller_8java =
[
    [ "controller.BlacklistController", "classcontroller_1_1_blacklist_controller.html", "classcontroller_1_1_blacklist_controller" ]
];