var classmodel_1_1servizi_1_1_backup_test =
[
    [ "cleanup", "classmodel_1_1servizi_1_1_backup_test.html#a40b200cd66852344c6c74cd83c3e49be", null ],
    [ "testBackupFallisceSeEseguibileManca", "classmodel_1_1servizi_1_1_backup_test.html#a7ab42a5641b33e281fccade9c3ccb59b", null ],
    [ "testBackupGestisceCartellaInesistente", "classmodel_1_1servizi_1_1_backup_test.html#a13184bf665b5f64981f82739af723473", null ],
    [ "testBackupGestisceCartellaNull", "classmodel_1_1servizi_1_1_backup_test.html#ad1d19af3a1845190daced13e6c9c6948", null ]
];