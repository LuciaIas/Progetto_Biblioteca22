var _aggiungi_libro_controller_8java =
[
    [ "controller.catalogo.AggiungiLibroController", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller.html", "classcontroller_1_1catalogo_1_1_aggiungi_libro_controller" ]
];