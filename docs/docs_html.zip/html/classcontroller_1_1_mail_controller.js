var classcontroller_1_1_mail_controller =
[
    [ "initialize", "classcontroller_1_1_mail_controller.html#a413b2051db9b72a73ce1204e58b37701", null ]
];