var classcontroller_1_1catalogo_1_1_modifica_libro_controller =
[
    [ "buttonInitialize", "classcontroller_1_1catalogo_1_1_modifica_libro_controller.html#ad09a9d6cf463b1bd543b62e24b40d4d3", null ],
    [ "initialize", "classcontroller_1_1catalogo_1_1_modifica_libro_controller.html#a07d7f53fd968c99a53bf8f5e5a024e21", null ],
    [ "settingForm", "classcontroller_1_1catalogo_1_1_modifica_libro_controller.html#a56fe415d38ac0a8f683bb903fdf8a4f8", null ],
    [ "updateAutori", "classcontroller_1_1catalogo_1_1_modifica_libro_controller.html#a60b63ad38e27c6aa3e6d434a6d04be3e", null ]
];