var classcontroller_1_1_blacklist_controller =
[
    [ "initialize", "classcontroller_1_1_blacklist_controller.html#a95c0ac20eba95e1ad342e588b0f3e42f", null ],
    [ "searchFunction", "classcontroller_1_1_blacklist_controller.html#a389be97e4c849b736ecadc5dcbb2bb19", null ],
    [ "updateUtentiList", "classcontroller_1_1_blacklist_controller.html#aa92bd7020d8af88ccd6707e9eeabe7df", null ]
];