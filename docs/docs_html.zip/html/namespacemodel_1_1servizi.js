var namespacemodel_1_1servizi =
[
    [ "Backup", "classmodel_1_1servizi_1_1_backup.html", null ],
    [ "BackupTest", "classmodel_1_1servizi_1_1_backup_test.html", "classmodel_1_1servizi_1_1_backup_test" ],
    [ "Catalogo", "classmodel_1_1servizi_1_1_catalogo.html", "classmodel_1_1servizi_1_1_catalogo" ],
    [ "CatalogoTest", "classmodel_1_1servizi_1_1_catalogo_test.html", "classmodel_1_1servizi_1_1_catalogo_test" ],
    [ "ControlloFormato", "classmodel_1_1servizi_1_1_controllo_formato.html", null ],
    [ "ControlloFormatoTest", "classmodel_1_1servizi_1_1_controllo_formato_test.html", "classmodel_1_1servizi_1_1_controllo_formato_test" ],
    [ "DataBase", "classmodel_1_1servizi_1_1_data_base.html", null ],
    [ "DataBaseTest", "classmodel_1_1servizi_1_1_data_base_test.html", "classmodel_1_1servizi_1_1_data_base_test" ],
    [ "EmailInvia", "classmodel_1_1servizi_1_1_email_invia.html", null ],
    [ "EmailInviaTest", "classmodel_1_1servizi_1_1_email_invia_test.html", "classmodel_1_1servizi_1_1_email_invia_test" ],
    [ "EmailLegge", "classmodel_1_1servizi_1_1_email_legge.html", null ],
    [ "EmailLeggeTest", "classmodel_1_1servizi_1_1_email_legge_test.html", "classmodel_1_1servizi_1_1_email_legge_test" ],
    [ "OperazioniGiornaliere", "classmodel_1_1servizi_1_1_operazioni_giornaliere.html", null ],
    [ "OperazioniGiornaliereTest", "classmodel_1_1servizi_1_1_operazioni_giornaliere_test.html", "classmodel_1_1servizi_1_1_operazioni_giornaliere_test" ],
    [ "Prestito", "classmodel_1_1servizi_1_1_prestito.html", "classmodel_1_1servizi_1_1_prestito" ],
    [ "PrestitoTest", "classmodel_1_1servizi_1_1_prestito_test.html", "classmodel_1_1servizi_1_1_prestito_test" ]
];