var _configurazione_8java =
[
    [ "model.Configurazione", "classmodel_1_1_configurazione.html", null ]
];