var _utenti_controller_8java =
[
    [ "controller.utenti.UtentiController", "classcontroller_1_1utenti_1_1_utenti_controller.html", "classcontroller_1_1utenti_1_1_utenti_controller" ]
];