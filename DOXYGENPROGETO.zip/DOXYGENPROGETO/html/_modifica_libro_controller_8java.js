var _modifica_libro_controller_8java =
[
    [ "Controller.Catalogo.ModificaLibroController", "class_controller_1_1_catalogo_1_1_modifica_libro_controller.html", "class_controller_1_1_catalogo_1_1_modifica_libro_controller" ]
];