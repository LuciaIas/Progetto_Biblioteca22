var namespace_controller_1_1_catalogo =
[
    [ "addBookController", "class_controller_1_1_catalogo_1_1add_book_controller.html", "class_controller_1_1_catalogo_1_1add_book_controller" ],
    [ "CatalogoController", "class_controller_1_1_catalogo_1_1_catalogo_controller.html", "class_controller_1_1_catalogo_1_1_catalogo_controller" ],
    [ "ModificaLibroController", "class_controller_1_1_catalogo_1_1_modifica_libro_controller.html", "class_controller_1_1_catalogo_1_1_modifica_libro_controller" ]
];