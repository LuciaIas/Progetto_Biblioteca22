var class_controller_1_1_catalogo_1_1_modifica_libro_controller =
[
    [ "ButtonInitialize", "class_controller_1_1_catalogo_1_1_modifica_libro_controller.html#a73ea67e8fbab0bd31f5c0f3c37385ad9", null ],
    [ "initialize", "class_controller_1_1_catalogo_1_1_modifica_libro_controller.html#a5c01457b0ae04246740e887477591489", null ],
    [ "SettingForm", "class_controller_1_1_catalogo_1_1_modifica_libro_controller.html#a73c19fbfbbbccd909a1f998dcf6d9a04", null ],
    [ "UpdateAutori", "class_controller_1_1_catalogo_1_1_modifica_libro_controller.html#a5e2c7411b43f74f8fdfad24fe9d80b17", null ]
];