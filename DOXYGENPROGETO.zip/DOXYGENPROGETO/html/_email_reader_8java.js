var _email_reader_8java =
[
    [ "Model.EmailReader", "class_model_1_1_email_reader.html", null ]
];