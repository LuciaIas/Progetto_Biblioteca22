var class_controller_1_1_catalogo_1_1add_book_controller =
[
    [ "ButtonInitialize", "class_controller_1_1_catalogo_1_1add_book_controller.html#af0ddad0b8be2e8ba09d169fe8f057b75", null ],
    [ "initialize", "class_controller_1_1_catalogo_1_1add_book_controller.html#aa4604c8b2da78f87fb6d553ce296072e", null ],
    [ "SettingForm", "class_controller_1_1_catalogo_1_1add_book_controller.html#aca02bcf905d94d19f28622249724407e", null ],
    [ "UpdateAutori", "class_controller_1_1_catalogo_1_1add_book_controller.html#aecf85a10b55d72f0beeb65b9b9fd7221", null ]
];