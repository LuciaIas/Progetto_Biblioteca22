var _email_info_8java =
[
    [ "Model.EmailInfo", "class_model_1_1_email_info.html", "class_model_1_1_email_info" ]
];