var _daily_task_8java =
[
    [ "Model.DailyTask", "class_model_1_1_daily_task.html", null ]
];