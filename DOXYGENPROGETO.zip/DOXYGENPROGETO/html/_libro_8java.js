var _libro_8java =
[
    [ "Model.DataClass.Libro", "class_model_1_1_data_class_1_1_libro.html", "class_model_1_1_data_class_1_1_libro" ]
];