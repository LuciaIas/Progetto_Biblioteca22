var _notify_controller_8java =
[
    [ "Controller.NotifyController", "class_controller_1_1_notify_controller.html", "class_controller_1_1_notify_controller" ]
];