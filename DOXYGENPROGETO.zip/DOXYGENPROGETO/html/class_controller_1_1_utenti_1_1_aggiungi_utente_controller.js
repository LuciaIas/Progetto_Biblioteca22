var class_controller_1_1_utenti_1_1_aggiungi_utente_controller =
[
    [ "ButtonInitialize", "class_controller_1_1_utenti_1_1_aggiungi_utente_controller.html#a5a5d148a7605ab854417eeeb0b5a1635", null ],
    [ "initialize", "class_controller_1_1_utenti_1_1_aggiungi_utente_controller.html#afad174a811cba47cf59dc934cc54f255", null ]
];