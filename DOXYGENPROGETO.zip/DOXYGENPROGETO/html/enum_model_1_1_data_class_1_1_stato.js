var enum_model_1_1_data_class_1_1_stato =
[
    [ "ATTIVO", "enum_model_1_1_data_class_1_1_stato.html#abea129eb807ff6db863cdbbe081d0618", null ],
    [ "IN_RITARDO", "enum_model_1_1_data_class_1_1_stato.html#a6cb674f205cce55941fdad6a514e60c9", null ],
    [ "PROROGATO", "enum_model_1_1_data_class_1_1_stato.html#a85ec9b73bd5f423ce2fdccf5e15983e4", null ],
    [ "RESTITUITO", "enum_model_1_1_data_class_1_1_stato.html#a3cab94e50bcf3339f79977e26f890077", null ]
];