var _dashboard_controller_8java =
[
    [ "Controller.DashboardController", "class_controller_1_1_dashboard_controller.html", "class_controller_1_1_dashboard_controller" ]
];