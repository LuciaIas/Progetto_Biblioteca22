var class_controller_1_1_blacklist_controller =
[
    [ "initialize", "class_controller_1_1_blacklist_controller.html#a39f8ba4fa96ff3a247cce472f578b217", null ],
    [ "SearchFunction", "class_controller_1_1_blacklist_controller.html#a9fd079f7258e0013618eb4e3e6882c27", null ],
    [ "updateUtentiList", "class_controller_1_1_blacklist_controller.html#af2f2479b1799acce88c85b5c34674368", null ]
];