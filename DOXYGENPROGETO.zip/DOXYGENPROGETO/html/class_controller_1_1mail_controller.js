var class_controller_1_1mail_controller =
[
    [ "initialize", "class_controller_1_1mail_controller.html#afafc60139fe40e83c750f08753ee76f8", null ]
];