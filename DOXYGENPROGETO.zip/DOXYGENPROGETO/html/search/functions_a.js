var searchData=
[
  ['removebibliotecario_0',['RemoveBibliotecario',['../class_model_1_1_data_base.html#a552c1caf95a9ad07e3c612d68d971b80',1,'Model::DataBase']]],
  ['removebook_1',['RemoveBook',['../class_model_1_1_data_base.html#a1c8ab790dfcc80c8419973343438dae1',1,'Model::DataBase']]],
  ['removeprestito_2',['RemovePrestito',['../class_model_1_1_data_base.html#a9744944a35605a4d3b4fca5d9092b34f',1,'Model::DataBase']]],
  ['removeuser_3',['RemoveUser',['../class_model_1_1_data_base.html#a44b502f7234c20e6ea620ad523b1e392',1,'Model::DataBase']]],
  ['restituisci_4',['Restituisci',['../class_model_1_1_data_base.html#a857d4a37032d3d42d27a0bc9b9ae32bb',1,'Model::DataBase']]],
  ['rimuovilibro_5',['rimuoviLibro',['../class_model_1_1_catalogo.html#af7c04e450e0d0f5e229d6e5342fed4d2',1,'Model::Catalogo']]]
];
