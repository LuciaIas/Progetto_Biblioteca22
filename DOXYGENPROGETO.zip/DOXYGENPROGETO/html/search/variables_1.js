var searchData=
[
  ['in_5fritardo_0',['IN_RITARDO',['../enum_model_1_1_data_class_1_1_stato.html#a6cb674f205cce55941fdad6a514e60c9',1,'Model::DataClass::Stato']]],
  ['isbn_1',['isbn',['../class_controller_1_1_catalogo_1_1_modifica_libro_controller.html#a053d4f6586c41bed95e94413facb7aea',1,'Controller::Catalogo::ModificaLibroController']]]
];
