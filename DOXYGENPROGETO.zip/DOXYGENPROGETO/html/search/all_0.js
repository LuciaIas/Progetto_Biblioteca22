var searchData=
[
  ['addautore_0',['addAutore',['../class_model_1_1_data_base.html#ab2d6a4723ba5cbfc3b15984f539b8d63',1,'Model::DataBase']]],
  ['addbook_1',['addBook',['../class_model_1_1_data_base.html#aa68ffca28cfa344021cc58eef8cddc09',1,'Model::DataBase']]],
  ['addbookcontroller_2',['addBookController',['../class_controller_1_1_catalogo_1_1add_book_controller.html',1,'Controller::Catalogo']]],
  ['addbookcontroller_2ejava_3',['addBookController.java',['../add_book_controller_8java.html',1,'']]],
  ['addprestito_4',['addPrestito',['../class_model_1_1_data_base.html#a8c205b8d8f2261f83dbabe70d31eaef0',1,'Model::DataBase']]],
  ['adduser_5',['addUser',['../class_model_1_1_data_base.html#a9b69e151b1d2990978462dbeef8b585c',1,'Model::DataBase']]],
  ['aggiungilibro_6',['aggiungiLibro',['../class_model_1_1_catalogo.html#afc547f9c92fc7e216df36ca7df9bf448',1,'Model::Catalogo']]],
  ['aggiungiprestitocontroller_7',['AggiungiPrestitoController',['../class_controller_1_1_prestito_restituzione_1_1_aggiungi_prestito_controller.html',1,'Controller::PrestitoRestituzione']]],
  ['aggiungiprestitocontroller_2ejava_8',['AggiungiPrestitoController.java',['../_aggiungi_prestito_controller_8java.html',1,'']]],
  ['aggiungiutentecontroller_9',['AggiungiUtenteController',['../class_controller_1_1_utenti_1_1_aggiungi_utente_controller.html',1,'Controller::Utenti']]],
  ['aggiungiutentecontroller_2ejava_10',['AggiungiUtenteController.java',['../_aggiungi_utente_controller_8java.html',1,'']]],
  ['attivo_11',['ATTIVO',['../enum_model_1_1_data_class_1_1_stato.html#abea129eb807ff6db863cdbbe081d0618',1,'Model::DataClass::Stato']]],
  ['autore_12',['Autore',['../class_model_1_1_data_class_1_1_autore.html',1,'Model.DataClass.Autore'],['../class_model_1_1_data_class_1_1_autore.html#a388a49493656b4eb499656652cf043e2',1,'Model.DataClass.Autore.Autore()']]],
  ['autore_2ejava_13',['Autore.java',['../_autore_8java.html',1,'']]],
  ['avviataskdimezzanotte_14',['avviaTaskDiMezzanotte',['../class_model_1_1_daily_task.html#a4667e7149356feadd98b45a84249ecfd',1,'Model::DailyTask']]]
];
