var searchData=
[
  ['tostring_0',['toString',['../class_model_1_1_data_class_1_1_autore.html#a6e34eff61a2e9083a39a9e033ac34920',1,'Model.DataClass.Autore.toString()'],['../class_model_1_1_data_class_1_1_libro.html#a2a89ae5ac20fc6ee5e6aebbb98d215c6',1,'Model.DataClass.Libro.toString()'],['../class_model_1_1_data_class_1_1_user.html#ab3acef2cac2fc127dedafb2ad7bf1834',1,'Model.DataClass.User.toString()'],['../class_model_1_1_email_info.html#a41f58162fb6e6954c59640c6dd697fea',1,'Model.EmailInfo.toString()'],['../class_model_1_1_prestito.html#af2f6246887effcce24a248d7a55e5a89',1,'Model.Prestito.toString()']]]
];
