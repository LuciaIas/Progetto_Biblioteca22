var searchData=
[
  ['backupservice_0',['BackupService',['../class_model_1_1_backup_service.html',1,'Model']]],
  ['blacklistcontroller_1',['BlacklistController',['../class_controller_1_1_blacklist_controller.html',1,'Controller']]]
];
