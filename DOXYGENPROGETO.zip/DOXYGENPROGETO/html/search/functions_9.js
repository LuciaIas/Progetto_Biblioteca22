var searchData=
[
  ['preliminaryfunctions_0',['PreliminaryFunctions',['../classmain_package_1_1main.html#a97ff054e616181d9095dd8c791d50ebd',1,'mainPackage::main']]],
  ['prestito_1',['Prestito',['../class_model_1_1_prestito.html#aad91142abe83370d5102466db5135b39',1,'Model::Prestito']]],
  ['prorogaprestito_2',['ProrogaPrestito',['../class_model_1_1_data_base.html#a11153b896bd8f94375baccfbd0ac5662',1,'Model::DataBase']]]
];
