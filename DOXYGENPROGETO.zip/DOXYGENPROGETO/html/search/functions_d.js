var searchData=
[
  ['unsetblacklisted_0',['UnsetBlackListed',['../class_model_1_1_data_base.html#aa1ff1e24f5f0fb379088d02f3281ff1a',1,'Model::DataBase']]],
  ['updateautori_1',['UpdateAutori',['../class_controller_1_1_catalogo_1_1add_book_controller.html#aecf85a10b55d72f0beeb65b9b9fd7221',1,'Controller.Catalogo.addBookController.UpdateAutori()'],['../class_controller_1_1_catalogo_1_1_modifica_libro_controller.html#a5e2c7411b43f74f8fdfad24fe9d80b17',1,'Controller.Catalogo.ModificaLibroController.UpdateAutori()']]],
  ['updatecatalogo_2',['updateCatalogo',['../class_controller_1_1_catalogo_1_1_catalogo_controller.html#ae8f6caf7198b15e4479243828e79e1b7',1,'Controller::Catalogo::CatalogoController']]],
  ['updateprestiti_3',['updatePrestiti',['../class_controller_1_1_prestito_restituzione_1_1_prestito_restituzione_controller.html#aa26a4fce0e06f97b7fd7b51687d3bf51',1,'Controller::PrestitoRestituzione::PrestitoRestituzioneController']]],
  ['updateutentilist_4',['updateUtentiList',['../class_controller_1_1_blacklist_controller.html#af2f2479b1799acce88c85b5c34674368',1,'Controller.BlacklistController.updateUtentiList()'],['../class_controller_1_1_utenti_1_1_utenti_controller.html#a326771a18deb460fc8eca8079ae629b9',1,'Controller.Utenti.UtentiController.updateUtentiList()']]],
  ['user_5',['User',['../class_model_1_1_data_class_1_1_user.html#a7c46819b12faf672270584ea5fe14c7c',1,'Model::DataClass::User']]]
];
