var searchData=
[
  ['dailytask_0',['DailyTask',['../class_model_1_1_daily_task.html',1,'Model']]],
  ['dashboardcontroller_1',['DashboardController',['../class_controller_1_1_dashboard_controller.html',1,'Controller']]],
  ['database_2',['DataBase',['../class_model_1_1_data_base.html',1,'Model']]]
];
