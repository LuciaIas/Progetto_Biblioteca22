var searchData=
[
  ['dbinitialize_0',['DBInitialize',['../class_model_1_1_data_base.html#a207e1ed795475a0d52aea0248808883b',1,'Model::DataBase']]]
];
