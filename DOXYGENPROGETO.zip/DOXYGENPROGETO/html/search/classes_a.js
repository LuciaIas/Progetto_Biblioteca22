var searchData=
[
  ['scenetransition_0',['SceneTransition',['../class_model_1_1_scene_transition.html',1,'Model']]],
  ['stato_1',['Stato',['../enum_model_1_1_data_class_1_1_stato.html',1,'Model::DataClass']]]
];
