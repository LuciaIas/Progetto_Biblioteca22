var searchData=
[
  ['addautore_0',['addAutore',['../class_model_1_1_data_base.html#ab2d6a4723ba5cbfc3b15984f539b8d63',1,'Model::DataBase']]],
  ['addbook_1',['addBook',['../class_model_1_1_data_base.html#aa68ffca28cfa344021cc58eef8cddc09',1,'Model::DataBase']]],
  ['addprestito_2',['addPrestito',['../class_model_1_1_data_base.html#a8c205b8d8f2261f83dbabe70d31eaef0',1,'Model::DataBase']]],
  ['adduser_3',['addUser',['../class_model_1_1_data_base.html#a9b69e151b1d2990978462dbeef8b585c',1,'Model::DataBase']]],
  ['aggiungilibro_4',['aggiungiLibro',['../class_model_1_1_catalogo.html#afc547f9c92fc7e216df36ca7df9bf448',1,'Model::Catalogo']]],
  ['autore_5',['Autore',['../class_model_1_1_data_class_1_1_autore.html#a388a49493656b4eb499656652cf043e2',1,'Model::DataClass::Autore']]],
  ['avviataskdimezzanotte_6',['avviaTaskDiMezzanotte',['../class_model_1_1_daily_task.html#a4667e7149356feadd98b45a84249ecfd',1,'Model::DailyTask']]]
];
