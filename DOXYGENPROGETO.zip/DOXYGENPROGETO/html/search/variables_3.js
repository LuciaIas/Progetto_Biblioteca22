var searchData=
[
  ['prorogato_0',['PROROGATO',['../enum_model_1_1_data_class_1_1_stato.html#a85ec9b73bd5f423ce2fdccf5e15983e4',1,'Model::DataClass::Stato']]]
];
