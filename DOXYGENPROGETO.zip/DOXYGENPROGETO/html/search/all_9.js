var searchData=
[
  ['notifycontroller_0',['NotifyController',['../class_controller_1_1_notify_controller.html',1,'Controller']]],
  ['notifycontroller_2ejava_1',['NotifyController.java',['../_notify_controller_8java.html',1,'']]]
];
