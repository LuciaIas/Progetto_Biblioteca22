var searchData=
[
  ['notifycontroller_0',['NotifyController',['../class_controller_1_1_notify_controller.html',1,'Controller']]]
];
