var searchData=
[
  ['restituito_0',['RESTITUITO',['../enum_model_1_1_data_class_1_1_stato.html#a3cab94e50bcf3339f79977e26f890077',1,'Model::DataClass::Stato']]]
];
