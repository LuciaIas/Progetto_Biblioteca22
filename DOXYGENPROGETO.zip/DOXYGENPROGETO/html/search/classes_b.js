var searchData=
[
  ['user_0',['User',['../class_model_1_1_data_class_1_1_user.html',1,'Model::DataClass']]],
  ['utenticontroller_1',['UtentiController',['../class_controller_1_1_utenti_1_1_utenti_controller.html',1,'Controller::Utenti']]]
];
