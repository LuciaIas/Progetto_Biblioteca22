var searchData=
[
  ['inseriscipasswordpermodificacontroller_0',['InserisciPasswordPerModificaController',['../class_controller_1_1_inserisci_password_per_modifica_controller.html',1,'Controller']]]
];
