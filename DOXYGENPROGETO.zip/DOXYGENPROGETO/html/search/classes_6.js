var searchData=
[
  ['libro_0',['Libro',['../class_model_1_1_data_class_1_1_libro.html',1,'Model::DataClass']]]
];
