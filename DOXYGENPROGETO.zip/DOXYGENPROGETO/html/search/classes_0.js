var searchData=
[
  ['addbookcontroller_0',['addBookController',['../class_controller_1_1_catalogo_1_1add_book_controller.html',1,'Controller::Catalogo']]],
  ['aggiungiprestitocontroller_1',['AggiungiPrestitoController',['../class_controller_1_1_prestito_restituzione_1_1_aggiungi_prestito_controller.html',1,'Controller::PrestitoRestituzione']]],
  ['aggiungiutentecontroller_2',['AggiungiUtenteController',['../class_controller_1_1_utenti_1_1_aggiungi_utente_controller.html',1,'Controller::Utenti']]],
  ['autore_3',['Autore',['../class_model_1_1_data_class_1_1_autore.html',1,'Model::DataClass']]]
];
