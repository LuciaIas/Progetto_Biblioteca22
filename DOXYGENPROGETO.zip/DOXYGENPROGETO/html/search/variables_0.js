var searchData=
[
  ['attivo_0',['ATTIVO',['../enum_model_1_1_data_class_1_1_stato.html#abea129eb807ff6db863cdbbe081d0618',1,'Model::DataClass::Stato']]]
];
