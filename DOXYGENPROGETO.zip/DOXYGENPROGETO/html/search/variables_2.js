var searchData=
[
  ['matricola_0',['matricola',['../class_controller_1_1_utenti_1_1_modifica_utente_controller.html#a5e6a4123e32c33f74bffc60bca19f574',1,'Controller::Utenti::ModificaUtenteController']]],
  ['max_5fautors_1',['MAX_AUTORS',['../class_controller_1_1_catalogo_1_1add_book_controller.html#ae444971f7e8d0c347cca386d3a886607',1,'Controller::Catalogo::addBookController']]],
  ['max_5fbooks_2',['MAX_BOOKS',['../class_controller_1_1_catalogo_1_1_catalogo_controller.html#af69f4c4c787b302b273c17c720e400d2',1,'Controller::Catalogo::CatalogoController']]],
  ['max_5floan_3',['MAX_LOAN',['../class_controller_1_1_prestito_restituzione_1_1_prestito_restituzione_controller.html#a862901d6be24fec9cd23078e081ffaaf',1,'Controller::PrestitoRestituzione::PrestitoRestituzioneController']]],
  ['max_5fusers_4',['MAX_USERS',['../class_controller_1_1_utenti_1_1_utenti_controller.html#a93f21b905de58b55a36eae4250a0289c',1,'Controller::Utenti::UtentiController']]],
  ['max_5fwrited_5',['MAX_WRITED',['../class_controller_1_1_catalogo_1_1add_book_controller.html#a9d72052362c6d260a4fb602605006196',1,'Controller::Catalogo::addBookController']]]
];
