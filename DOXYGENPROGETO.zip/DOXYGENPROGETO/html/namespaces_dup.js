var namespaces_dup =
[
    [ "Controller", "namespace_controller.html", "namespace_controller" ],
    [ "mainPackage", "namespacemain_package.html", "namespacemain_package" ],
    [ "Model", "namespace_model.html", "namespace_model" ]
];