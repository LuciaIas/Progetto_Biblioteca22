var _prestito_8java =
[
    [ "Model.Prestito", "class_model_1_1_prestito.html", "class_model_1_1_prestito" ]
];