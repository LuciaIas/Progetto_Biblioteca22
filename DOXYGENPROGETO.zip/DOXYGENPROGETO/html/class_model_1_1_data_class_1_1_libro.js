var class_model_1_1_data_class_1_1_libro =
[
    [ "Libro", "class_model_1_1_data_class_1_1_libro.html#affe292c5c37eba0c2f16fcaff76d85d5", null ],
    [ "compareTo", "class_model_1_1_data_class_1_1_libro.html#afe214c421355bbcbec0c51bbf6ec0e23", null ],
    [ "getAnno_pubblicazione", "class_model_1_1_data_class_1_1_libro.html#aefa1d9e44bc196a99f95a4f29ab09c35", null ],
    [ "getAutori", "class_model_1_1_data_class_1_1_libro.html#a363e8d75a38c5e450037b223fa1fc011", null ],
    [ "getEditore", "class_model_1_1_data_class_1_1_libro.html#a523c45669c560be9e5a87f610d45040e", null ],
    [ "getIsbn", "class_model_1_1_data_class_1_1_libro.html#a87e28deff8b5053e8e07c73d79b6b478", null ],
    [ "getNumero_copieDisponibili", "class_model_1_1_data_class_1_1_libro.html#a687faa075faedbcefbcad6a60bbbd8f8", null ],
    [ "getTitolo", "class_model_1_1_data_class_1_1_libro.html#a2f501b40286872dea26dbf464e264e65", null ],
    [ "getUrl", "class_model_1_1_data_class_1_1_libro.html#a64874755c64fb42d1353f85b1eb0a1f1", null ],
    [ "setAnno_pubblicazione", "class_model_1_1_data_class_1_1_libro.html#a42b2ed4a22650ffe6a0b4108e3315749", null ],
    [ "setAutori", "class_model_1_1_data_class_1_1_libro.html#aadb30efbbc4dc9e86c5d441724983744", null ],
    [ "setEditore", "class_model_1_1_data_class_1_1_libro.html#a414e8234b567c16d1d0bfe6ca21b8f96", null ],
    [ "setIsbn", "class_model_1_1_data_class_1_1_libro.html#aea95e2bed570ef9a5de9248e3e22474a", null ],
    [ "setNumero_copieDisponibili", "class_model_1_1_data_class_1_1_libro.html#a083e3ef89a1cdff4d6db3d2badeddaba", null ],
    [ "setTitolo", "class_model_1_1_data_class_1_1_libro.html#a138fa392cb306ee832737e65ab8ce33c", null ],
    [ "setUrl", "class_model_1_1_data_class_1_1_libro.html#a847f253905ef9acc2acdcdee403e9744", null ],
    [ "toString", "class_model_1_1_data_class_1_1_libro.html#a2a89ae5ac20fc6ee5e6aebbb98d215c6", null ]
];