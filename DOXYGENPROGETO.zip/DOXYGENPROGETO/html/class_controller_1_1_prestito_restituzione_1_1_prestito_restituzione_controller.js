var class_controller_1_1_prestito_restituzione_1_1_prestito_restituzione_controller =
[
    [ "ButtonInitialize", "class_controller_1_1_prestito_restituzione_1_1_prestito_restituzione_controller.html#a76fb339b88aa80404d09d02769f30b55", null ],
    [ "initialize", "class_controller_1_1_prestito_restituzione_1_1_prestito_restituzione_controller.html#aba1a2a5466df8bab5649beee6e43547c", null ],
    [ "MenuButtonInitialize", "class_controller_1_1_prestito_restituzione_1_1_prestito_restituzione_controller.html#aa15095ba6ad13d7b82c0e0104ff59e1c", null ],
    [ "SearchFunction", "class_controller_1_1_prestito_restituzione_1_1_prestito_restituzione_controller.html#a8c681d7fee7a26bc99af1c09bc36be1f", null ],
    [ "updatePrestiti", "class_controller_1_1_prestito_restituzione_1_1_prestito_restituzione_controller.html#aa26a4fce0e06f97b7fd7b51687d3bf51", null ]
];