var class_controller_1_1_utenti_1_1_modifica_utente_controller =
[
    [ "initialize", "class_controller_1_1_utenti_1_1_modifica_utente_controller.html#a580fc2523640289fd6ae6c79f882a63a", null ]
];