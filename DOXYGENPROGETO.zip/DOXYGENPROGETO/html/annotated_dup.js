var annotated_dup =
[
    [ "Controller", "namespace_controller.html", [
      [ "Catalogo", "namespace_controller_1_1_catalogo.html", [
        [ "addBookController", "class_controller_1_1_catalogo_1_1add_book_controller.html", "class_controller_1_1_catalogo_1_1add_book_controller" ],
        [ "CatalogoController", "class_controller_1_1_catalogo_1_1_catalogo_controller.html", "class_controller_1_1_catalogo_1_1_catalogo_controller" ],
        [ "ModificaLibroController", "class_controller_1_1_catalogo_1_1_modifica_libro_controller.html", "class_controller_1_1_catalogo_1_1_modifica_libro_controller" ]
      ] ],
      [ "PrestitoRestituzione", "namespace_controller_1_1_prestito_restituzione.html", [
        [ "AggiungiPrestitoController", "class_controller_1_1_prestito_restituzione_1_1_aggiungi_prestito_controller.html", "class_controller_1_1_prestito_restituzione_1_1_aggiungi_prestito_controller" ],
        [ "PrestitoRestituzioneController", "class_controller_1_1_prestito_restituzione_1_1_prestito_restituzione_controller.html", "class_controller_1_1_prestito_restituzione_1_1_prestito_restituzione_controller" ]
      ] ],
      [ "Utenti", "namespace_controller_1_1_utenti.html", [
        [ "AggiungiUtenteController", "class_controller_1_1_utenti_1_1_aggiungi_utente_controller.html", "class_controller_1_1_utenti_1_1_aggiungi_utente_controller" ],
        [ "ModificaUtenteController", "class_controller_1_1_utenti_1_1_modifica_utente_controller.html", "class_controller_1_1_utenti_1_1_modifica_utente_controller" ],
        [ "UtentiController", "class_controller_1_1_utenti_1_1_utenti_controller.html", "class_controller_1_1_utenti_1_1_utenti_controller" ]
      ] ],
      [ "BlacklistController", "class_controller_1_1_blacklist_controller.html", "class_controller_1_1_blacklist_controller" ],
      [ "ControllerAccess", "class_controller_1_1_controller_access.html", "class_controller_1_1_controller_access" ],
      [ "DashboardController", "class_controller_1_1_dashboard_controller.html", "class_controller_1_1_dashboard_controller" ],
      [ "InserisciPasswordPerModificaController", "class_controller_1_1_inserisci_password_per_modifica_controller.html", "class_controller_1_1_inserisci_password_per_modifica_controller" ],
      [ "mailController", "class_controller_1_1mail_controller.html", "class_controller_1_1mail_controller" ],
      [ "NotifyController", "class_controller_1_1_notify_controller.html", "class_controller_1_1_notify_controller" ],
      [ "PasswordChargeController", "class_controller_1_1_password_charge_controller.html", "class_controller_1_1_password_charge_controller" ]
    ] ],
    [ "mainPackage", "namespacemain_package.html", [
      [ "main", "classmain_package_1_1main.html", "classmain_package_1_1main" ]
    ] ],
    [ "Model", "namespace_model.html", [
      [ "DataClass", "namespace_model_1_1_data_class.html", [
        [ "Autore", "class_model_1_1_data_class_1_1_autore.html", "class_model_1_1_data_class_1_1_autore" ],
        [ "Libro", "class_model_1_1_data_class_1_1_libro.html", "class_model_1_1_data_class_1_1_libro" ],
        [ "Stato", "enum_model_1_1_data_class_1_1_stato.html", "enum_model_1_1_data_class_1_1_stato" ],
        [ "User", "class_model_1_1_data_class_1_1_user.html", "class_model_1_1_data_class_1_1_user" ]
      ] ],
      [ "BackupService", "class_model_1_1_backup_service.html", null ],
      [ "Catalogo", "class_model_1_1_catalogo.html", "class_model_1_1_catalogo" ],
      [ "CheckFormat", "class_model_1_1_check_format.html", null ],
      [ "DailyTask", "class_model_1_1_daily_task.html", null ],
      [ "DataBase", "class_model_1_1_data_base.html", null ],
      [ "EmailInfo", "class_model_1_1_email_info.html", "class_model_1_1_email_info" ],
      [ "EmailReader", "class_model_1_1_email_reader.html", null ],
      [ "EmailSender", "class_model_1_1_email_sender.html", null ],
      [ "Prestito", "class_model_1_1_prestito.html", "class_model_1_1_prestito" ],
      [ "SceneTransition", "class_model_1_1_scene_transition.html", null ]
    ] ]
];