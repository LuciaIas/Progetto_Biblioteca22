var namespace_model_1_1_data_class =
[
    [ "Autore", "class_model_1_1_data_class_1_1_autore.html", "class_model_1_1_data_class_1_1_autore" ],
    [ "Libro", "class_model_1_1_data_class_1_1_libro.html", "class_model_1_1_data_class_1_1_libro" ],
    [ "Stato", "enum_model_1_1_data_class_1_1_stato.html", "enum_model_1_1_data_class_1_1_stato" ],
    [ "User", "class_model_1_1_data_class_1_1_user.html", "class_model_1_1_data_class_1_1_user" ]
];