var namespace_controller_1_1_prestito_restituzione =
[
    [ "AggiungiPrestitoController", "class_controller_1_1_prestito_restituzione_1_1_aggiungi_prestito_controller.html", "class_controller_1_1_prestito_restituzione_1_1_aggiungi_prestito_controller" ],
    [ "PrestitoRestituzioneController", "class_controller_1_1_prestito_restituzione_1_1_prestito_restituzione_controller.html", "class_controller_1_1_prestito_restituzione_1_1_prestito_restituzione_controller" ]
];