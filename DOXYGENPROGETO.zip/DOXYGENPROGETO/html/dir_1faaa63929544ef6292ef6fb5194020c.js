var dir_1faaa63929544ef6292ef6fb5194020c =
[
    [ "AggiungiPrestitoController.java", "_aggiungi_prestito_controller_8java.html", "_aggiungi_prestito_controller_8java" ],
    [ "PrestitoRestituzioneController.java", "_prestito_restituzione_controller_8java.html", "_prestito_restituzione_controller_8java" ]
];