var class_model_1_1_email_info =
[
    [ "EmailInfo", "class_model_1_1_email_info.html#a20bbe951d467dca1ee007e2d159ab71d", null ],
    [ "getDataInvio", "class_model_1_1_email_info.html#af8816cf2fd7d02b91611f217d781d2a8", null ],
    [ "getDestinatario", "class_model_1_1_email_info.html#ab2cd21c40fe31e101c348918876295ce", null ],
    [ "getOggetto", "class_model_1_1_email_info.html#a80bc53c04bc53252044bf777caa9fd8f", null ],
    [ "toString", "class_model_1_1_email_info.html#a41f58162fb6e6954c59640c6dd697fea", null ]
];