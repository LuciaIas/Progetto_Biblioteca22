var class_controller_1_1_dashboard_controller =
[
    [ "ButtonInitialize", "class_controller_1_1_dashboard_controller.html#aea65b6dc9afd66f2b184090de5579781", null ],
    [ "initialize", "class_controller_1_1_dashboard_controller.html#a4b0f93122e4457d324c9ec907867ee2f", null ],
    [ "LabelInitialize", "class_controller_1_1_dashboard_controller.html#a66f019ca970e4ba34122d0d5ea6877bc", null ]
];