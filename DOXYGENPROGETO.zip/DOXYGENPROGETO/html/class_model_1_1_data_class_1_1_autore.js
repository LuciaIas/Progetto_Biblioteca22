var class_model_1_1_data_class_1_1_autore =
[
    [ "Autore", "class_model_1_1_data_class_1_1_autore.html#a388a49493656b4eb499656652cf043e2", null ],
    [ "getCognome", "class_model_1_1_data_class_1_1_autore.html#acad2b8dc394809720f5da82252396f5c", null ],
    [ "getData_nascita", "class_model_1_1_data_class_1_1_autore.html#aa4b0ea3e4a14231721b9cf45cfa65399", null ],
    [ "getId", "class_model_1_1_data_class_1_1_autore.html#a84bbd8e5430fb7717151c69ded360086", null ],
    [ "getNome", "class_model_1_1_data_class_1_1_autore.html#a5ef7d51cf80ef62936b88a9430ff8f9d", null ],
    [ "getOpere_scritte", "class_model_1_1_data_class_1_1_autore.html#ab27033a8ad7ca08f3295e6361fd6bd5e", null ],
    [ "setCognome", "class_model_1_1_data_class_1_1_autore.html#a31861a4680e1d78b60c4fbe4c4244132", null ],
    [ "setData_nascita", "class_model_1_1_data_class_1_1_autore.html#a94e765d9b0a2a7e08b3c0ddfa6795aa7", null ],
    [ "setId", "class_model_1_1_data_class_1_1_autore.html#a49ace937a19eb334a35c5501a10ce167", null ],
    [ "setNome", "class_model_1_1_data_class_1_1_autore.html#ad57b6123ebcea22a730b42e4c26a26d0", null ],
    [ "setOpere_scritte", "class_model_1_1_data_class_1_1_autore.html#a09cf6a657b788754913d659f6097650a", null ],
    [ "toString", "class_model_1_1_data_class_1_1_autore.html#a6e34eff61a2e9083a39a9e033ac34920", null ]
];