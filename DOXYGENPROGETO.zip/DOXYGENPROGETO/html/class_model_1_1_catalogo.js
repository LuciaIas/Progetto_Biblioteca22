var class_model_1_1_catalogo =
[
    [ "Catalogo", "class_model_1_1_catalogo.html#a95adfa0646feaa667b19e1508fc20c25", null ],
    [ "aggiungiLibro", "class_model_1_1_catalogo.html#afc547f9c92fc7e216df36ca7df9bf448", null ],
    [ "cercaPerAutore", "class_model_1_1_catalogo.html#a4e3f6fc0fd1db7d3eb400b6931e41c0f", null ],
    [ "cercaPerIsbn", "class_model_1_1_catalogo.html#a10e26887c2c19042fd791437bf6d9d96", null ],
    [ "cercaPerTitolo", "class_model_1_1_catalogo.html#a7558f214e849f6b22cdd12fd42fae9ca", null ],
    [ "getLibri", "class_model_1_1_catalogo.html#ab3acb670449b1f90f11d70d442648fd3", null ],
    [ "rimuoviLibro", "class_model_1_1_catalogo.html#af7c04e450e0d0f5e229d6e5342fed4d2", null ],
    [ "sort", "class_model_1_1_catalogo.html#a3a631f26cf148a20947bfd9e7cfcc323", null ]
];