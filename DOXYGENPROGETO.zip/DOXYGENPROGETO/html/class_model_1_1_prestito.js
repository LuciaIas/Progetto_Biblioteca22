var class_model_1_1_prestito =
[
    [ "Prestito", "class_model_1_1_prestito.html#aad91142abe83370d5102466db5135b39", null ],
    [ "getData_scadenza", "class_model_1_1_prestito.html#a3a934c78264cc5dc28cc936e3f65ade4", null ],
    [ "getInizio_prestito", "class_model_1_1_prestito.html#a0adb3cdc87c458171b81784a79355c9c", null ],
    [ "getIsbn", "class_model_1_1_prestito.html#adefc331ce389a60136ec4a2cc9827d09", null ],
    [ "getMatricola", "class_model_1_1_prestito.html#abbafad1e46c6ca723414d8f95f8e588d", null ],
    [ "getRestituzione", "class_model_1_1_prestito.html#a6d99dea3eec71b55cb58b13ff9cb3dca", null ],
    [ "getStato", "class_model_1_1_prestito.html#a46497acf47321fbb84f1b79c5eeeb39e", null ],
    [ "setData_scadenza", "class_model_1_1_prestito.html#a1e289cffbf74b8fa2116666645e3828e", null ],
    [ "setInizio_prestito", "class_model_1_1_prestito.html#a21f46de437b35e975cc4901cfea48e98", null ],
    [ "setIsbn", "class_model_1_1_prestito.html#abecbd85b8b9271646e8b97cf3654b0dd", null ],
    [ "setMatricola", "class_model_1_1_prestito.html#a5b21b08de66d733c27d5887cbf02f9f6", null ],
    [ "setRestituzione", "class_model_1_1_prestito.html#a90968489b9d651d64655115f939abdac", null ],
    [ "setStato", "class_model_1_1_prestito.html#a4feb5a93706af2087158d1f72629d7a0", null ],
    [ "toString", "class_model_1_1_prestito.html#af2f6246887effcce24a248d7a55e5a89", null ]
];