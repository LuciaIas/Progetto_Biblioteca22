var _blacklist_controller_8java =
[
    [ "Controller.BlacklistController", "class_controller_1_1_blacklist_controller.html", "class_controller_1_1_blacklist_controller" ]
];