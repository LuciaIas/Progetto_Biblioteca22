var dir_be3527604e4e74237403effc3d3ea29b =
[
    [ "Autore.java", "_autore_8java.html", "_autore_8java" ],
    [ "Libro.java", "_libro_8java.html", "_libro_8java" ],
    [ "Stato.java", "_stato_8java.html", "_stato_8java" ],
    [ "User.java", "_user_8java.html", "_user_8java" ]
];