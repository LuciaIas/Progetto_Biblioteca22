var class_controller_1_1_catalogo_1_1_catalogo_controller =
[
    [ "initialize", "class_controller_1_1_catalogo_1_1_catalogo_controller.html#a8e43fb439636236e8ad36c06ac10c662", null ],
    [ "launchAddBookForm", "class_controller_1_1_catalogo_1_1_catalogo_controller.html#aeb3d01c639097ff051225c8a738eee02", null ],
    [ "SearchFunction", "class_controller_1_1_catalogo_1_1_catalogo_controller.html#acf9439fccc2359c49f55187c24e14b35", null ],
    [ "updateCatalogo", "class_controller_1_1_catalogo_1_1_catalogo_controller.html#ae8f6caf7198b15e4479243828e79e1b7", null ]
];