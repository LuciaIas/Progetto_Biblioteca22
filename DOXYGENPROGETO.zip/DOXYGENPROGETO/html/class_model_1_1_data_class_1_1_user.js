var class_model_1_1_data_class_1_1_user =
[
    [ "User", "class_model_1_1_data_class_1_1_user.html#a7c46819b12faf672270584ea5fe14c7c", null ],
    [ "getCognome", "class_model_1_1_data_class_1_1_user.html#aa81815ace875a3a825f465e549f67571", null ],
    [ "getMail", "class_model_1_1_data_class_1_1_user.html#aede46efc762df3bfa9f9db112ac2e877", null ],
    [ "getMatricola", "class_model_1_1_data_class_1_1_user.html#ab68f38af3b61c4d8f10d8e2257d3c000", null ],
    [ "getNome", "class_model_1_1_data_class_1_1_user.html#a2695ad3c4b4c7a07b1430243ebad7f41", null ],
    [ "isBloccato", "class_model_1_1_data_class_1_1_user.html#ac03be4518e560ef753ea188e8feaa208", null ],
    [ "setBloccato", "class_model_1_1_data_class_1_1_user.html#a8c5804c78603e383fec88dce585476af", null ],
    [ "setCognome", "class_model_1_1_data_class_1_1_user.html#a8726476a85cbc6b6e92a5d2ac9d1f217", null ],
    [ "setMail", "class_model_1_1_data_class_1_1_user.html#a5b40685cfe49a845cde1279dcca68610", null ],
    [ "setMatricola", "class_model_1_1_data_class_1_1_user.html#a80ef9e959047fe68e8ca49fa30510936", null ],
    [ "setNome", "class_model_1_1_data_class_1_1_user.html#a73b36aa5186223c5d34be35a9f59511b", null ],
    [ "toString", "class_model_1_1_data_class_1_1_user.html#ab3acef2cac2fc127dedafb2ad7bf1834", null ]
];