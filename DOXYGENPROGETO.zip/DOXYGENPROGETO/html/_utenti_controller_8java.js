var _utenti_controller_8java =
[
    [ "Controller.Utenti.UtentiController", "class_controller_1_1_utenti_1_1_utenti_controller.html", "class_controller_1_1_utenti_1_1_utenti_controller" ]
];