var class_controller_1_1_notify_controller =
[
    [ "initialize", "class_controller_1_1_notify_controller.html#a3833092e000edfe0f50459617dfa71af", null ]
];