var namespace_model =
[
    [ "DataClass", "namespace_model_1_1_data_class.html", "namespace_model_1_1_data_class" ],
    [ "BackupService", "class_model_1_1_backup_service.html", null ],
    [ "Catalogo", "class_model_1_1_catalogo.html", "class_model_1_1_catalogo" ],
    [ "CheckFormat", "class_model_1_1_check_format.html", null ],
    [ "DailyTask", "class_model_1_1_daily_task.html", null ],
    [ "DataBase", "class_model_1_1_data_base.html", null ],
    [ "EmailInfo", "class_model_1_1_email_info.html", "class_model_1_1_email_info" ],
    [ "EmailReader", "class_model_1_1_email_reader.html", null ],
    [ "EmailSender", "class_model_1_1_email_sender.html", null ],
    [ "Prestito", "class_model_1_1_prestito.html", "class_model_1_1_prestito" ],
    [ "SceneTransition", "class_model_1_1_scene_transition.html", null ]
];