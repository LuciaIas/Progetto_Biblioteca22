var _stato_8java =
[
    [ "Model.DataClass.Stato", "enum_model_1_1_data_class_1_1_stato.html", "enum_model_1_1_data_class_1_1_stato" ]
];