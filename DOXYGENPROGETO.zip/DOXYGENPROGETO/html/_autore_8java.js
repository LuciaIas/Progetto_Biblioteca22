var _autore_8java =
[
    [ "Model.DataClass.Autore", "class_model_1_1_data_class_1_1_autore.html", "class_model_1_1_data_class_1_1_autore" ]
];