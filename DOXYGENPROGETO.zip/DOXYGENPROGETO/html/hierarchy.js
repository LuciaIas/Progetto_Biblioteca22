var hierarchy =
[
    [ "Controller.Catalogo.addBookController", "class_controller_1_1_catalogo_1_1add_book_controller.html", null ],
    [ "Controller.PrestitoRestituzione.AggiungiPrestitoController", "class_controller_1_1_prestito_restituzione_1_1_aggiungi_prestito_controller.html", null ],
    [ "Controller.Utenti.AggiungiUtenteController", "class_controller_1_1_utenti_1_1_aggiungi_utente_controller.html", null ],
    [ "Application", null, [
      [ "mainPackage.main", "classmain_package_1_1main.html", null ]
    ] ],
    [ "Model.DataClass.Autore", "class_model_1_1_data_class_1_1_autore.html", null ],
    [ "Model.BackupService", "class_model_1_1_backup_service.html", null ],
    [ "Controller.BlacklistController", "class_controller_1_1_blacklist_controller.html", null ],
    [ "Model.Catalogo", "class_model_1_1_catalogo.html", null ],
    [ "Controller.Catalogo.CatalogoController", "class_controller_1_1_catalogo_1_1_catalogo_controller.html", null ],
    [ "Model.CheckFormat", "class_model_1_1_check_format.html", null ],
    [ "Comparable", null, [
      [ "Model.DataClass.Libro", "class_model_1_1_data_class_1_1_libro.html", null ]
    ] ],
    [ "Controller.ControllerAccess", "class_controller_1_1_controller_access.html", null ],
    [ "Model.DailyTask", "class_model_1_1_daily_task.html", null ],
    [ "Controller.DashboardController", "class_controller_1_1_dashboard_controller.html", null ],
    [ "Model.DataBase", "class_model_1_1_data_base.html", null ],
    [ "Model.EmailInfo", "class_model_1_1_email_info.html", null ],
    [ "Model.EmailReader", "class_model_1_1_email_reader.html", null ],
    [ "Model.EmailSender", "class_model_1_1_email_sender.html", null ],
    [ "Controller.InserisciPasswordPerModificaController", "class_controller_1_1_inserisci_password_per_modifica_controller.html", null ],
    [ "Controller.mailController", "class_controller_1_1mail_controller.html", null ],
    [ "Controller.Catalogo.ModificaLibroController", "class_controller_1_1_catalogo_1_1_modifica_libro_controller.html", null ],
    [ "Controller.Utenti.ModificaUtenteController", "class_controller_1_1_utenti_1_1_modifica_utente_controller.html", null ],
    [ "Controller.NotifyController", "class_controller_1_1_notify_controller.html", null ],
    [ "Controller.PasswordChargeController", "class_controller_1_1_password_charge_controller.html", null ],
    [ "Model.Prestito", "class_model_1_1_prestito.html", null ],
    [ "Controller.PrestitoRestituzione.PrestitoRestituzioneController", "class_controller_1_1_prestito_restituzione_1_1_prestito_restituzione_controller.html", null ],
    [ "Model.SceneTransition", "class_model_1_1_scene_transition.html", null ],
    [ "Model.DataClass.Stato", "enum_model_1_1_data_class_1_1_stato.html", null ],
    [ "Model.DataClass.User", "class_model_1_1_data_class_1_1_user.html", null ],
    [ "Controller.Utenti.UtentiController", "class_controller_1_1_utenti_1_1_utenti_controller.html", null ]
];