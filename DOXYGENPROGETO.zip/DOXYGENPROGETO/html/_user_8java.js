var _user_8java =
[
    [ "Model.DataClass.User", "class_model_1_1_data_class_1_1_user.html", "class_model_1_1_data_class_1_1_user" ]
];