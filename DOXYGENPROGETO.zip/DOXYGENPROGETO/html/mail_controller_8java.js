var mail_controller_8java =
[
    [ "Controller.mailController", "class_controller_1_1mail_controller.html", "class_controller_1_1mail_controller" ]
];